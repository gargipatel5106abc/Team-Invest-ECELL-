export type Language = 'en' | 'hi' | 'ta';

export type PersonaType = 'beginner' | 'active_trader';

export interface UserProfile {
  name: string;
  language: Language;
  persona: PersonaType | null;
  quizPassed: boolean;
  unlockedInstruments: {
    equity: boolean;
    mutualFunds: boolean;
    fAndO: boolean;
    commodities: boolean;
  };
  simulatedBalance: number;
  realBalance: number;
  milestones: {
    completedTutorialsCount: number;
    completedMockTrades: number;
    quizExecuted: boolean;
  };
  isSubscribed: boolean;
}

export interface StockData {
  symbol: string;
  name: string;
  segment: 'equity' | 'fando';
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  open: number;
  volume: number;
  sector: string;
  description: string;
  riskRating: 'High' | 'Medium' | 'Low';
  aiRecommendation: string;
  aiScore: number; // 0 to 100
  rsi?: number;
  macd?: string;
  historicalData: { time: string; price: number }[];
}

export interface Order {
  id: string;
  symbol: string;
  stockName: string;
  type: 'BUY' | 'SELL';
  orderType: 'LIMIT' | 'MARKET';
  price: number;
  quantity: number;
  timestamp: string;
  status: 'PENDING' | 'EXECUTED' | 'REJECTED';
  isSimulated: boolean;
  segment: 'equity' | 'fando';
}

export interface Holding {
  symbol: string;
  stockName: string;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
  segment: 'equity' | 'fando';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export interface BacktestResult {
  symbol: string;
  initialCapital: number;
  finalValue: number;
  netProfit: number;
  netProfitPercent: number;
  totalTrades: number;
  winRate: number;
  chartData: { date: string; close: number; equity: number }[];
}
