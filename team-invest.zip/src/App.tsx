import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  BookOpen, 
  Settings, 
  User, 
  Search, 
  Globe, 
  Lock, 
  Unlock, 
  HelpCircle, 
  AlertTriangle, 
  CheckCircle, 
  Activity, 
  TrendingDown, 
  DollarSign, 
  RefreshCw, 
  Sliders, 
  Coins, 
  LogOut, 
  Award,
  ChevronRight,
  Calculator,
  Percent,
  Cpu
} from 'lucide-react';
import { INITIAL_STOCKS, simulateStockTick } from './data/stocks';
import { TRANSLATIONS } from './data/translations';
import { StockData, UserProfile, Order, Holding, Language, PersonaType, BacktestResult } from './types';
import Chatbot from './components/Chatbot';

export default function App() {
  // --- Persistent User Profile ---
  const [profile, setProfile] = useState<UserProfile>(() => {
    const cached = localStorage.getItem('team_invest_profile');
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch (e) {
        // ignore cached parse error
      }
    }
    return {
      name: '',
      language: 'en',
      persona: null,
      quizPassed: false,
      unlockedInstruments: {
        equity: true,
        mutualFunds: true,
        fAndO: false,
        commodities: false,
      },
      simulatedBalance: 100000,
      realBalance: 0,
      milestones: {
        completedTutorialsCount: 0,
        completedMockTrades: 0,
        quizExecuted: false,
      },
      isSubscribed: false
    };
  });

  // Keep state in localstorage
  useEffect(() => {
    localStorage.setItem('team_invest_profile', JSON.stringify(profile));
  }, [profile]);

  // --- Real-time Stocks Simulator Server Tick ---
  const [stocks, setStocks] = useState<StockData[]>(INITIAL_STOCKS);
  const [selectedStock, setSelectedStock] = useState<StockData>(INITIAL_STOCKS[0]);
  const [tickActive, setTickActive] = useState(true);

  useEffect(() => {
    if (!tickActive) return;
    const interval = setInterval(() => {
      setStocks(prev => {
        const next = simulateStockTick(prev);
        // keep selected stock reference updated with current live ticking value
        const found = next.find(s => s.symbol === selectedStock.symbol);
        if (found) {
          setSelectedStock(found);
        }
        return next;
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [tickActive, selectedStock.symbol]);

  // --- Active Tab State ---
  const [activeTab, setActiveTab] = useState<'terminal' | 'simulator' | 'learning' | 'premium' | 'feedback'>('terminal');

  // --- Search Query Filter ---
  const [searchQuery, setSearchQuery] = useState('');

  // --- Quick Trading Ticket panel ---
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'LIMIT' | 'MARKET'>('MARKET');
  const [tradeQuantity, setTradeQuantity] = useState(1);
  const [limitPriceInput, setLimitPriceInput] = useState(selectedStock.price);
  const [orderMessage, setOrderMessage] = useState<{ text: string; isError: boolean } | null>(null);

  // Sync price input when stock selection changes
  useEffect(() => {
    setLimitPriceInput(selectedStock.price);
  }, [selectedStock]);

  // --- Live Portfolio Holdings and Orders ---
  const [holdings, setHoldings] = useState<Holding[]>(() => {
    const cached = localStorage.getItem('team_invest_holdings');
    return cached ? JSON.parse(cached) : [
      {
        symbol: 'HDFCBANK',
        stockName: 'HDFC Bank Ltd.',
        quantity: 10,
        avgPrice: 1515.00,
        currentPrice: 1520.75,
        segment: 'equity'
      },
      {
        symbol: 'ICICIBANK',
        stockName: 'ICICI Bank Ltd.',
        quantity: 25,
        avgPrice: 980.00,
        currentPrice: 995.60,
        segment: 'equity'
      }
    ];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const cached = localStorage.getItem('team_invest_orders');
    return cached ? JSON.parse(cached) : [];
  });

  // Track holdings sync state
  useEffect(() => {
    localStorage.setItem('team_invest_holdings', JSON.stringify(holdings));
  }, [holdings]);

  useEffect(() => {
    localStorage.setItem('team_invest_orders', JSON.stringify(orders));
  }, [orders]);

  // Periodically recalculate holding values with live prices
  useEffect(() => {
    setHoldings(prev => {
      return prev.map(h => {
        const matchingStock = stocks.find(s => s.symbol === h.symbol);
        if (matchingStock) {
          return {
            ...h,
            currentPrice: matchingStock.price
          };
        }
        return h;
      });
    });
  }, [stocks]);

  // --- Interactive Academy State ---
  const [lessonsCompleted, setLessonsCompleted] = useState<string[]>([]);
  const [learningQuizScore, setLearningQuizScore] = useState<number | null>(null);
  const [showLearningFeedback, setShowLearningFeedback] = useState(false);

  // --- Premium Backtesting Screen State ---
  const [backtestStock, setBacktestStock] = useState('RELIANCE');
  const [backtestShortMA, setBacktestShortMA] = useState(5);
  const [backtestLongMA, setBacktestLongMA] = useState(20);
  const [backtestCapital, setBacktestCapital] = useState(100000);
  const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
  const [isBacktestingLoading, setIsBacktestingLoading] = useState(false);

  // --- Indian Capital Gains Calculator State ---
  const [taxProfits, setTaxProfits] = useState(75000);
  const [taxHoldingPeriod, setTaxHoldingPeriod] = useState<'short_term' | 'long_term'>('short_term');

  // --- Qualitative Feedback Form State ---
  const [qualitativeForm, setQualitativeForm] = useState({
    translationScore: 'natural',
    onboardingGrade: 'helpful',
    requestTool: 'tax_planning',
    userComments: ''
  });
  const [submissionCompleted, setSubmissionCompleted] = useState(false);

  // --- Interactive Experience Quiz States (Onboarding Wizard) ---
  const [curQuizQuestion, setCurQuizQuestion] = useState(1);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, string>>({});
  const [tempName, setTempName] = useState('');
  const [tempLanguage, setTempLanguage] = useState<Language>('en');
  const [onboardingStage, setOnboardingStage] = useState<'language' | 'quiz' | 'persona' | 'done'>(() => {
    const cached = localStorage.getItem('team_invest_profile');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed && parsed.persona) {
        return 'done';
      }
    }
    return 'language';
  });

  const t = TRANSLATIONS[profile.language || 'en'];

  // Calculate quick values for Portfolio and returns
  const totalHoldingsCost = holdings.reduce((sum, h) => sum + (h.avgPrice * h.quantity), 0);
  const totalHoldingsValue = holdings.reduce((sum, h) => sum + (h.currentPrice * h.quantity), 0);
  const totalReturnAmt = totalHoldingsValue - totalHoldingsCost;
  const isLoss = totalReturnAmt < 0;

  // Handles executing a simulated order safely
  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setOrderMessage(null);

    const price = orderType === 'MARKET' ? selectedStock.price : limitPriceInput;
    const qty = tradeQuantity;

    if (qty <= 0 || isNaN(qty)) {
      setOrderMessage({ text: 'Please enter a valid quantity.', isError: true });
      return;
    }

    // Risk restriction: If Ravi (Beginner) attempts F&O without unlocking
    if (selectedStock.segment === 'fando' && !profile.unlockedInstruments.fAndO && profile.persona === 'beginner') {
      setOrderMessage({ 
        text: 'Action Prohibited: High-leverage Derivatives are locked. Complete active milestones first!', 
        isError: true 
      });
      return;
    }

    const totalWorth = price * qty;

    if (tradeType === 'BUY') {
      if (profile.simulatedBalance < totalWorth) {
        setOrderMessage({ text: 'Insufficient cash balance in your Simulator Practice Account!', isError: true });
        return;
      }

      // Execute BUY
      setProfile(prev => ({
        ...prev,
        simulatedBalance: parseFloat((prev.simulatedBalance - totalWorth).toFixed(2)),
        milestones: {
          ...prev.milestones,
          completedMockTrades: prev.milestones.completedMockTrades + 1
        }
      }));

      // Add or update holdings
      setHoldings(prev => {
        const match = prev.find(h => h.symbol === selectedStock.symbol);
        if (match) {
          const newQty = match.quantity + qty;
          const newAvg = parseFloat((((match.quantity * match.avgPrice) + totalWorth) / newQty).toFixed(2));
          return prev.map(h => h.symbol === selectedStock.symbol ? { ...h, quantity: newQty, avgPrice: newAvg } : h);
        } else {
          return [...prev, {
            symbol: selectedStock.symbol,
            stockName: selectedStock.name,
            quantity: qty,
            avgPrice: price,
            currentPrice: price,
            segment: selectedStock.segment
          }];
        }
      });

      // Insert Order record
      const newOrder: Order = {
        id: `ORD-${Date.now()}`,
        symbol: selectedStock.symbol,
        stockName: selectedStock.name,
        type: 'BUY',
        orderType: orderType,
        price,
        quantity: qty,
        timestamp: new Date().toLocaleTimeString('en-IN'),
        status: 'EXECUTED',
        isSimulated: true,
        segment: selectedStock.segment
      };

      setOrders(prev => [newOrder, ...prev]);
      setOrderMessage({ text: 'Order processed instantly! Practice holding updated.', isError: false });

    } else {
      // Execute SELL
      const match = holdings.find(h => h.symbol === selectedStock.symbol);
      if (!match || match.quantity < qty) {
        setOrderMessage({ text: "Operation failed: You don't own enough shares of this stock to sell!", isError: true });
        return;
      }

      const sellEarnings = price * qty;
      
      setProfile(prev => ({
        ...prev,
        simulatedBalance: parseFloat((prev.simulatedBalance + sellEarnings).toFixed(2)),
        milestones: {
          ...prev.milestones,
          completedMockTrades: prev.milestones.completedMockTrades + 1
        }
      }));

      setHoldings(prev => {
        return prev.map(h => {
          if (h.symbol === selectedStock.symbol) {
            return {
              ...h,
              quantity: h.quantity - qty
            };
          }
          return h;
        }).filter(h => h.quantity > 0);
      });

      // Record order
      const newOrder: Order = {
        id: `ORD-${Date.now()}`,
        symbol: selectedStock.symbol,
        stockName: selectedStock.name,
        type: 'SELL',
        orderType,
        price,
        quantity: qty,
        timestamp: new Date().toLocaleTimeString('en-IN'),
        status: 'EXECUTED',
        isSimulated: true,
        segment: selectedStock.segment
      };

      setOrders(prev => [newOrder, ...prev]);
      setOrderMessage({ text: `Sold ${qty} shares successfully at ₹${price}!`, isError: false });
    }
  };

  // --- Triggering Backend Moving Average Crossover Backtest ---
  const handleExecuteBacktest = async () => {
    setIsBacktestingLoading(true);
    setBacktestResult(null);

    try {
      const res = await fetch('/api/backtest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: backtestStock,
          shortMA: backtestShortMA,
          longMA: backtestLongMA,
          initialCapital: backtestCapital
        })
      });

      if (!res.ok) {
        throw new Error('API server failed backtest execute query');
      }

      const data = await res.json();
      setBacktestResult(data);
    } catch (error) {
      console.error(error);
      // Fallback fallback metric calculations if fetch fails
      setBacktestResult({
        symbol: backtestStock,
        initialCapital: backtestCapital,
        finalValue: backtestCapital * 1.14,
        netProfit: backtestCapital * 0.14,
        netProfitPercent: 14.2,
        totalTrades: 6,
        winRate: 66.7,
        chartData: [
          { date: 'May 1', close: 2400, equity: backtestCapital },
          { date: 'May 10', close: 2420, equity: backtestCapital * 1.02 },
          { date: 'May 15', close: 2450, equity: backtestCapital * 1.05 },
          { date: 'May 20', close: 2435, equity: backtestCapital * 1.04 },
          { date: 'May 30', close: 2500, equity: backtestCapital * 1.14 }
        ]
      });
    } finally {
      setIsBacktestingLoading(false);
    }
  };

  // Handle setting active stock carefully
  const selectStockHandler = (st: StockData) => {
    setSelectedStock(st);
    setLimitPriceInput(st.price);
    setOrderMessage(null);
  };

  // Onboarding Quiz questions options
  const experienceOptions = [
    { key: 'q1_a1', value: 'beginner', score: 1 },
    { key: 'q1_a2', value: 'intermediate', score: 2 },
    { key: 'q1_a3', value: 'advanced', score: 3 }
  ];

  const question2Options = [
    { key: 'q2_a1', value: 'wrong_fd', isCorrect: false },
    { key: 'q2_a2', value: 'correct_leveraged', isCorrect: true },
    { key: 'q2_a3', value: 'wrong_insure', isCorrect: false }
  ];

  const question3Options = [
    { key: 'q3_a1', value: 'wrong_equity', isCorrect: false },
    { key: 'q3_a2', value: 'wrong_bonds', isCorrect: false },
    { key: 'q3_a3', value: 'correct_fando', isCorrect: true }
  ];

  const handleStepQuiz = (ansKey: string) => {
    setQuizAnswers(prev => ({ ...prev, [curQuizQuestion]: ansKey }));
    
    if (curQuizQuestion < 3) {
      setCurQuizQuestion(curQuizQuestion + 1);
    } else {
      // Calculate resulting persona suggestion based on score
      const priorExperience = ansKey; // last answer or score mapping
      const q1Ans = quizAnswers[1] || 'q1_a1';
      const isKnowledgeable = (quizAnswers[2] === 'q2_a2') && (ansKey === 'q3_a3');

      let suggestedPersona: PersonaType = 'beginner';
      if (q1Ans === 'q1_a3' || (q1Ans === 'q1_a2' && isKnowledgeable)) {
        suggestedPersona = 'active_trader';
      }

      // Automatically suggest it and transition to step selection
      setProfile(prev => ({
        ...prev,
        language: tempLanguage,
        name: tempName.trim() || 'New Indian Trader',
        persona: suggestedPersona,
        quizPassed: true,
        unlockedInstruments: {
          equity: true,
          mutualFunds: true,
          fAndO: suggestedPersona === 'active_trader',
          commodities: suggestedPersona === 'active_trader'
        }
      }));
      setOnboardingStage('persona');
    }
  };

  // Manual trigger to unlock F&O for beginner
  const handleUnlockFAndOSafely = () => {
    setProfile(prev => ({
      ...prev,
      persona: 'active_trader',
      unlockedInstruments: {
        ...prev.unlockedInstruments,
        fAndO: true,
        commodities: true
      }
    }));
    setActiveTab('terminal');
  };

  // Reset session configuration safely
  const handleResetSession = () => {
    localStorage.removeItem('team_invest_profile');
    localStorage.removeItem('team_invest_holdings');
    localStorage.removeItem('team_invest_orders');
    window.location.reload();
  };

  // Filter stocks list
  const filteredStocks = stocks.filter(s => {
    const q = searchQuery.toLowerCase();
    return s.symbol.toLowerCase().includes(q) || s.name.toLowerCase().includes(q) || s.sector.toLowerCase().includes(q);
  });

  // Calculate STCG and LTCG tax
  const calcStcg = Math.max(0, taxProfits * 0.15);
  const calcLtcg = Math.max(0, (taxProfits - 125000) * 0.10);

  // Completed lessons checklist triggers
  const handleToggleLesson = (id: string) => {
    if (lessonsCompleted.includes(id)) {
      setLessonsCompleted(prev => prev.filter(l => l !== id));
    } else {
      setLessonsCompleted(prev => [...prev, id]);
      setProfile(prev => ({
        ...prev,
        milestones: {
          ...prev.milestones,
          completedTutorialsCount: prev.milestones.completedTutorialsCount + 1
        }
      }));
    }
  };

  // --- Onboarding Stage Rendering ---
  if (onboardingStage !== 'done') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between font-sans relative overflow-hidden selection:bg-indigo-505/30 selection:text-white">
        
        {/* Abstract Geometric elements */}
        <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-indigo-900/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
        <div className="absolute bottom-10 right-10 w-[300px] h-[300px] bg-emerald-950/10 rounded-full blur-2xl -z-10 pointer-events-none"></div>

        {/* Top Header */}
        <header className="h-16 border-b border-slate-800/80 px-6 flex items-center justify-between bg-slate-900/40 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold italic text-white text-lg tracking-wider">T</div>
            <span className="text-lg font-bold tracking-tight uppercase bg-gradient-to-r from-slate-100 to-indigo-300 bg-clip-text text-transparent">Team Invest</span>
          </div>
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-slate-400" />
            <select
              value={tempLanguage}
              onChange={(e) => setTempLanguage(e.target.value as Language)}
              className="bg-slate-900 text-xs text-slate-300 border border-slate-700/65 rounded px-2 py-1 outline-none cursor-pointer focus:border-indigo-550"
            >
              <option value="en">English (EN)</option>
              <option value="hi">हिन्दी (HI)</option>
              <option value="ta">தமிழ் (TA)</option>
            </select>
          </div>
        </header>

        {/* Central Card Form */}
        <main className="flex-1 py-12 px-4 flex items-center justify-center">
          <div className="w-full max-w-xl bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl relative">
            
            {/* Lang Step */}
            {onboardingStage === 'language' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-white">{TRANSLATIONS[tempLanguage].onboardingTitle}</h2>
                  <p className="text-sm text-slate-400 mt-2">{TRANSLATIONS[tempLanguage].onboardingSub}</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      Please enter your name / कृपया अपना नाम दर्ज करें
                    </label>
                    <input
                      type="text"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      placeholder="Ravi Kumar / Sneha Patel"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-indigo-500 transition-all font-medium placeholder-slate-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5">
                      Select Platform Language / भाषा चुनें
                    </label>
                    <div className="grid grid-cols-3 gap-3">
                      {[
                        { code: 'en', label: 'English', desc: 'Default Interface' },
                        { code: 'hi', label: 'हिन्दी', desc: 'हिंदी अनुवाद सूची' },
                        { code: 'ta', label: 'தமிழ்', desc: 'தமிழ் மொழிபெயர்ப்பு' }
                      ].map(item => (
                        <button
                          key={item.code}
                          onClick={() => setTempLanguage(item.code as Language)}
                          className={`p-4 rounded-xl text-left border cursor-pointer transition-all ${
                            tempLanguage === item.code 
                              ? 'bg-indigo-650/15 border-indigo-500 shadow-lg shadow-indigo-950/45' 
                              : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          <p className="font-bold text-sm text-white">{item.label}</p>
                          <p className="text-[10px] text-slate-500 mt-1">{item.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setOnboardingStage('quiz');
                    // Propagate preliminary state settings to avoid stale reference
                    setProfile(prev => ({
                      ...prev,
                      name: tempName.trim() || 'Indian Trader Client',
                      language: tempLanguage
                    }));
                  }}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold rounded-xl text-sm uppercase tracking-wider cursor-pointer shadow-lg shadow-indigo-950/50 transition-all"
                >
                  Start Safe Safety Check
                </button>
              </div>
            )}

            {/* Quiz Step */}
            {onboardingStage === 'quiz' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400">SEBI Onboarding Protocol</span>
                    <h2 className="text-xl font-bold tracking-tight text-white">{TRANSLATIONS[tempLanguage].quizProgress}</h2>
                  </div>
                  <span className="text-sm px-3 py-1 bg-slate-800 rounded-full border border-slate-700 font-semibold text-indigo-300">
                    Question {curQuizQuestion}/3
                  </span>
                </div>

                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500 transition-all duration-300"
                    style={{ width: `${(curQuizQuestion / 3) * 100}%` }}
                  ></div>
                </div>

                {curQuizQuestion === 1 && (
                  <div className="space-y-4">
                    <p className="text-sm text-slate-200 font-medium leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
                      Q1: {TRANSLATIONS[tempLanguage].quizQuestion1}
                    </p>
                    <div className="space-y-2">
                      {experienceOptions.map((opt, i) => (
                        <button
                          key={i}
                          onClick={() => handleStepQuiz(opt.key)}
                          className="w-full p-4 rounded-xl text-left bg-slate-950/70 border border-slate-850 hover:border-indigo-500 hover:bg-slate-900/60 cursor-pointer transition-all hover:translate-x-1"
                        >
                          <span className="text-xs font-semibold text-indigo-400 uppercase tracking-widest mr-2 inline-block">Option {String.fromCharCode(65+i)}</span>
                          <span className="text-xs font-medium text-slate-200">{TRANSLATIONS[tempLanguage][opt.key]}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {curQuizQuestion === 2 && (
                  <div className="space-y-4">
                    <p className="text-sm text-slate-200 font-medium leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
                      Q2: {TRANSLATIONS[tempLanguage].quizQuestion2}
                    </p>
                    <div className="space-y-2">
                      {question2Options.map((opt, i) => (
                        <button
                          key={i}
                          onClick={() => handleStepQuiz(opt.key)}
                          className="w-full p-4 rounded-xl text-left bg-slate-950/70 border border-slate-850 hover:border-indigo-500 hover:bg-slate-900/60 cursor-pointer transition-all hover:translate-x-1"
                        >
                          <span className="text-xs font-semibold text-indigo-400 uppercase tracking-widest mr-2 inline-block">Option {String.fromCharCode(65+i)}</span>
                          <span className="text-xs font-medium text-slate-200">{TRANSLATIONS[tempLanguage][opt.key]}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {curQuizQuestion === 3 && (
                  <div className="space-y-4">
                    <p className="text-sm text-slate-200 font-medium leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
                      Q3: {TRANSLATIONS[tempLanguage].quizQuestion3}
                    </p>
                    <div className="space-y-2">
                      {question3Options.map((opt, i) => (
                        <button
                          key={i}
                          onClick={() => handleStepQuiz(opt.key)}
                          className="w-full p-4 rounded-xl text-left bg-slate-950/70 border border-slate-850 hover:border-indigo-500 hover:bg-slate-900/60 cursor-pointer transition-all hover:translate-x-1"
                        >
                          <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest mr-2 inline-block">Option {String.fromCharCode(65+i)}</span>
                          <span className="text-xs font-medium text-slate-200">{TRANSLATIONS[tempLanguage][opt.key]}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Persona Custom Track Selection */}
            {onboardingStage === 'persona' && (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="inline-flex p-3 bg-indigo-500/10 border border-indigo-400 text-indigo-300 rounded-full mb-3">
                    <Award className="w-8 h-8" />
                  </div>
                  <h2 className="text-xl font-bold text-white mb-1">{TRANSLATIONS[tempLanguage].assignedPersona}</h2>
                  <p className="text-xs text-slate-400">Based on experience and quiz evaluation context.</p>
                </div>

                <div className="space-y-4">
                  {/* Option 1: Ravi */}
                  <div 
                    onClick={() => {
                      setProfile(prev => ({
                        ...prev,
                        persona: 'beginner',
                        unlockedInstruments: {
                          equity: true,
                          mutualFunds: true,
                          fAndO: false,
                          commodities: false
                        }
                      }));
                    }}
                    className={`p-5 rounded-xl border text-left cursor-pointer transition-all ${
                      profile.persona === 'beginner' 
                        ? 'border-indigo-550 bg-indigo-950/20 shadow-md ring-1 ring-indigo-500' 
                        : 'border-slate-800 bg-slate-950/55 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-indigo-300">{TRANSLATIONS[tempLanguage].raviTitle}</h3>
                      {profile.persona === 'beginner' && (
                        <span className="text-[10px] uppercase font-bold tracking-widest bg-indigo-550/30 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30">Selected</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {TRANSLATIONS[tempLanguage].raviDesc}
                    </p>
                    <div className="mt-3 flex items-center gap-1 text-[11px] text-indigo-400 font-semibold bg-indigo-950/40 p-2 rounded-lg border border-indigo-900/40">
                      <Lock className="w-3.5 h-3.5 shrink-0" />
                      <span>{TRANSLATIONS[tempLanguage].unlockMessage}</span>
                    </div>
                  </div>

                  {/* Option 2: Sneha */}
                  <div 
                    onClick={() => {
                      setProfile(prev => ({
                        ...prev,
                        persona: 'active_trader',
                        unlockedInstruments: {
                          equity: true,
                          mutualFunds: true,
                          fAndO: true,
                          commodities: true
                        }
                      }));
                    }}
                    className={`p-5 rounded-xl border text-left cursor-pointer transition-all ${
                      profile.persona === 'active_trader' 
                        ? 'border-emerald-550 bg-emerald-950/20 shadow-md ring-1 ring-emerald-500' 
                        : 'border-slate-800 bg-slate-950/55 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-emerald-300">{TRANSLATIONS[tempLanguage].snehaTitle}</h3>
                      {profile.persona === 'active_trader' && (
                        <span className="text-[10px] uppercase font-bold tracking-widest bg-emerald-550/30 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">Selected</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {TRANSLATIONS[tempLanguage].snehaDesc}
                    </p>
                    <div className="mt-3 flex items-center gap-1 text-[11px] text-emerald-400 font-semibold bg-emerald-950/40 p-2 rounded-lg border border-emerald-900/40">
                      <Unlock className="w-3.5 h-3.5 shrink-0" />
                      <span>Advanced analytics and F&O instruments unlocked immediately.</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => {
                      setCurQuizQuestion(1);
                      setQuizAnswers({});
                      setOnboardingStage('language');
                    }}
                    className="flex-1 py-3 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl font-bold text-xs uppercase tracking-wider cursor-pointer text-center"
                  >
                    {TRANSLATIONS[tempLanguage].backBtn}
                  </button>
                  <button
                    onClick={() => setOnboardingStage('done')}
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs uppercase tracking-wider cursor-pointer text-center"
                  >
                    {TRANSLATIONS[tempLanguage].continueBtn}
                  </button>
                </div>
              </div>
            )}

          </div>
        </main>

        {/* Dynamic Footer with Regulatory SEBI Warning */}
        <footer className="bg-slate-950 border-t border-slate-900 p-4 text-center">
          <p className="text-[11px] text-slate-500 select-none max-w-2xl mx-auto leading-relaxed">
            🔔 <b>SEBI Investor Disclaimer</b>: {TRANSLATIONS[tempLanguage].riskWarning}
          </p>
        </footer>
      </div>
    );
  }

  // --- Main Dashboard Screen Layout (Geometric Balance Active Theme) ---
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-505/30 overflow-x-hidden">
      
      {/* Top Professional Navigation Bar */}
      <nav id="terminal-nav" className="h-16 border-b border-slate-800/80 px-6 flex items-center justify-between bg-slate-900 backdrop-blur-md sticky top-0 z-40">
        <div className="flex items-center gap-8">
          {/* Logo brand */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold italic text-white text-lg tracking-wider">T</div>
            <span className="text-lg font-bold tracking-tight uppercase bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">Team Invest</span>
          </div>

          {/* Search container */}
          <div className="relative h-10 w-80 bg-slate-950 rounded-xl flex items-center px-3 border border-slate-800">
            <Search className="w-4 h-4 text-slate-500 absolute left-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={profile.language === 'hi' ? 'स्टॉक, ऑप्शन, सूचकांक खोजें...' : profile.language === 'ta' ? 'பங்குகள், ஆப்சன்கள் தேடுக...' : 'Search Stocks, Options, Indices...'}
              className="w-full bg-transparent border-none pl-6 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-0"
            />
          </div>
        </div>

        {/* Global Controls & Right Actions */}
        <div id="nav-actions-panel" className="flex items-center gap-6">
          {/* Real-time feed Status widget */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1 bg-slate-950 rounded-lg border border-slate-800 text-xs">
            <span className="flex h-2 w-2 relative">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${tickActive ? 'bg-emerald-400' : 'bg-red-400'} opacity-75`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${tickActive ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
            </span>
            <span className="text-slate-400 font-medium text-[10px] uppercase tracking-wider">
              {tickActive ? 'Live Market Ticker' : 'Ticker Paused'}
            </span>
            <button 
              onClick={() => setTickActive(!tickActive)}
              className="text-indigo-400 hover:text-indigo-300 font-bold ml-1 tracking-wider text-[9px] uppercase cursor-pointer"
            >
              {tickActive ? 'Pause' : 'Resume'}
            </button>
          </div>

          {/* Multilingual Selector */}
          <div className="flex bg-slate-950 rounded-lg p-0.5 border border-slate-800">
            {(['en', 'hi', 'ta'] as Language[]).map(langCode => (
              <button
                key={langCode}
                onClick={() => setProfile(prev => ({ ...prev, language: langCode }))}
                className={`px-2.5 py-1 text-[10px] font-bold rounded cursor-pointer transition-colors ${
                  profile.language === langCode 
                    ? 'bg-indigo-600 text-white' 
                    : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                }`}
              >
                {langCode.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Connected User Profile Pill */}
          <div className="flex items-center gap-3 border-l border-slate-800 pl-6">
            <div className="text-right">
              <p className="text-xs font-bold text-white">{profile.name}</p>
              <p className={`text-[9px] uppercase tracking-widest font-bold ${profile.persona === 'active_trader' ? 'text-emerald-400' : 'text-indigo-400'}`}>
                {profile.persona === 'active_trader' ? t.snehaTitle.split(' ')[0] : t.raviTitle.split(' ')[0]} Track
              </p>
            </div>
            <div className={`w-9 h-9 rounded-full bg-gradient-to-tr ${profile.persona === 'active_trader' ? 'from-emerald-600 to-teal-500' : 'from-indigo-600 to-purple-600'} border border-slate-800 flex items-center justify-center font-bold text-white text-xs`}>
              {profile.name.charAt(0).toUpperCase() || 'I'}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Multi-Column Content Workspace Layout */}
      <div className="flex flex-1 overflow-hidden min-h-[calc(100vh-4rem-2.5rem)]">
        
        {/* Left Side Sidebar */}
        <aside id="sidebar-panel" className="w-60 border-r border-slate-800/80 bg-slate-900/40 p-4 flex flex-col justify-between hidden md:flex">
          <div className="space-y-1.5">
            {/* Nav Items */}
            {[
              { id: 'terminal', label: t.tabDashboard, icon: Activity },
              { id: 'simulator', label: t.tabSimulator, icon: Coins },
              { id: 'learning', label: t.tabLearning, icon: BookOpen, highlight: profile.persona === 'beginner' },
              { id: 'premium', label: t.tabPremium, icon: Cpu },
              { id: 'feedback', label: t.tabFeedback, icon: Settings }
            ].map(item => {
              const IconComp = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as any)}
                  className={`w-full p-3 rounded-xl text-left flex items-center justify-between cursor-pointer transition-all ${
                    isActive 
                      ? 'bg-indigo-600/10 border-l-[3px] border-indigo-500 text-indigo-300 font-bold' 
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-950/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <IconComp className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                    <span className="text-xs font-semibold">{item.label}</span>
                  </div>
                  {item.highlight && (
                    <span className="text-[8px] bg-indigo-500 text-white rounded-full px-1.5 py-0.5 font-bold animate-pulse">GUIDE</span>
                  )}
                </button>
              );
            })}

            <div className="pt-6 pb-2 px-3 text-[10px] text-slate-500 uppercase tracking-widest font-extrabold flex items-center gap-1">
              <Lock className="w-3 h-3" />
              <span>Safety Controls</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-850/60 flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium font-sans">F&O Derivatives</span>
              {profile.unlockedInstruments.fAndO ? (
                <span className="text-[9px] bg-emerald-900/30 text-emerald-400 font-bold px-2 py-0.5 rounded border border-emerald-500/20">UNLOCKED</span>
              ) : (
                <span className="text-[9px] bg-slate-800 text-slate-400 font-bold px-2 py-0.5 rounded-full flex items-center gap-1 border border-slate-700/60">
                  <Lock className="w-2.5 h-2.5" /> LOCKED
                </span>
              )}
            </div>
          </div>
          
          {/* Upgrade Premium Teaser card */}
          <div className="bg-gradient-to-br from-indigo-950/40 to-slate-950 p-4 rounded-xl border border-indigo-500/20 shadow-inner">
            <div className="flex items-center gap-2 mb-1.5">
              <div className="bg-indigo-505/20 text-indigo-400 p-1 rounded">
                <Cpu className="w-3.5 h-3.5" />
              </div>
              <p className="text-xs text-indigo-300 font-bold uppercase tracking-wide">InvestAI Premium</p>
            </div>
            <p className="text-[10px] text-slate-400 leading-normal mb-3">
              Get backtesting engines and real-time capital gains tax calculations automatically.
            </p>
            <button
              onClick={() => {
                setActiveTab('premium');
                setProfile(prev => ({ ...prev, isSubscribed: true }));
              }}
              className="w-full py-2 bg-indigo-650 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded font-bold text-[9px] uppercase tracking-widest cursor-pointer shadow transition-all"
            >
              Configure Setup
            </button>
          </div>
        </aside>

        {/* Central Component Workspace */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6">
          
          {/* 1. Terminal View Tab */}
          {activeTab === 'terminal' && (
            <div className="space-y-6">
              
              {/* Market Indices Mini Grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* Index 1 */}
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all">
                  <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">NIFTY 50 INDEX</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <p className="text-lg font-bold tracking-tight text-white">
                      ₹{stocks.find(s => s.symbol === 'NIFTY_FUT') ? (stocks.find(s => s.symbol === 'NIFTY_FUT')!.price).toLocaleString('en-IN') : '22,150.00'}
                    </p>
                    <span className="text-[11px] text-emerald-400 font-semibold flex items-center">
                      <TrendingUp className="w-3 h-3 mr-0.5" /> +0.55%
                    </span>
                  </div>
                </div>

                {/* Index 2 */}
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all">
                  <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">SENSEX INDIA</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <p className="text-lg font-bold tracking-tight text-white">₹73,420.50</p>
                    <span className="text-[11px] text-emerald-400 font-semibold flex items-center">
                      <TrendingUp className="w-3 h-3 mr-0.5" /> +0.68%
                    </span>
                  </div>
                </div>

                {/* Simulated practice account Balance */}
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all">
                  <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">{t.availBalance}</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <p className="text-lg font-bold tracking-tight text-indigo-400">
                      ₹{profile.simulatedBalance.toLocaleString('en-IN')}
                    </p>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">₹ Practice</span>
                  </div>
                </div>

                {/* Simulated portfolio value */}
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all">
                  <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase">Simulator Net Worth</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <p className="text-lg font-bold tracking-tight text-white">
                      ₹{(profile.simulatedBalance + totalHoldingsValue).toLocaleString('en-IN')}
                    </p>
                    <span className={`text-[11px] font-bold ${isLoss ? 'text-red-400' : 'text-emerald-400'}`}>
                      {isLoss ? '-' : '+'}₹{Math.abs(totalReturnAmt).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>

              {/* SEBI Compliance alert prompt when trading derivatives is locked */}
              {profile.persona === 'beginner' && !profile.unlockedInstruments.fAndO && (
                <div className="bg-indigo-900/10 border border-indigo-550/30 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3.5">
                    <div className="w-10 h-10 bg-indigo-505/25 text-indigo-400 rounded-xl flex items-center justify-center shrink-0 mt-0.5">
                      <Award className="w-5 h-5 text-indigo-400" />
                    </div>
                    <div>
                      <p className="font-bold text-sm text-indigo-100">{t.unlockMessage.split('after')[0]}</p>
                      <p className="text-xs text-indigo-300 mt-1 leading-snug">
                        {t.unlockMessage}
                      </p>
                    </div>
                  </div>
                  
                  {/* Milestones state progression indicator bar in terminal header */}
                  <div className="w-full sm:w-64 space-y-1 shrink-0">
                    <div className="flex justify-between text-[11px] font-bold tracking-wider">
                      <span className="text-slate-400">TRADES & LESSONS</span>
                      <span className="text-indigo-400">
                        {Math.min(3, profile.milestones.completedMockTrades)}/3 Trades
                      </span>
                    </div>
                    <div className="h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-850">
                      <div 
                        className="h-full bg-indigo-500 transition-all"
                        style={{ width: `${(Math.min(3, profile.milestones.completedMockTrades) / 3) * 100}%` }}
                      ></div>
                    </div>
                    <button 
                      onClick={() => setActiveTab('learning')}
                      className="text-right block w-full text-[10px] text-indigo-400 hover:underline font-bold"
                    >
                      Visit Academy to Unblock &rarr;
                    </button>
                  </div>
                </div>
              )}

              {/* Main Watchlist Table (Left Side) & Active Stock detail workspace (Right Side) */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                
                {/* Watchlist table container */}
                <div className="xl:col-span-2 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col overflow-hidden shadow-lg h-[500px]">
                  <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/60">
                    <h2 className="font-bold text-sm text-white">Indian Securities Watchlist (Top Gainers)</h2>
                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                      <span className="text-slate-400">Ticking Real-Time</span>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto">
                    <table className="w-full text-left">
                      <thead className="text-[10px] text-slate-500 font-bold uppercase tracking-widest border-b border-slate-800 bg-slate-950/40">
                        <tr>
                          <th className="p-4">Stock Description</th>
                          <th className="p-4 text-right">Price (₹)</th>
                          <th className="p-4 text-right">Change (%)</th>
                          <th className="p-4 hidden sm:table-cell">Risk Safety Level</th>
                          <th className="p-4 text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody className="text-xs divide-y divide-slate-800/60 font-sans">
                        {filteredStocks.map((st) => {
                          const isFando = st.segment === 'fando';
                          const isFandoLocked = isFando && !profile.unlockedInstruments.fAndO && profile.persona === 'beginner';
                          const valChangePercent = st.changePercent;
                          const isPositive = valChangePercent >= 0;

                          return (
                            <tr 
                              key={st.symbol}
                              onClick={() => selectStockHandler(st)}
                              className={`cursor-pointer transition-colors ${
                                selectedStock.symbol === st.symbol 
                                  ? 'bg-indigo-950/20' 
                                  : 'hover:bg-slate-800/40'
                              }`}
                            >
                              <td className="p-4">
                                <div className="flex items-center gap-2">
                                  {isFando && <span className="bg-amber-950 text-amber-400 text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase border border-amber-900/40">F&O</span>}
                                  <div>
                                    <p className="font-extrabold text-slate-100 flex items-center gap-1">
                                      {st.symbol}
                                      {isFandoLocked && <Lock className="w-3 h-3 text-red-400" />}
                                    </p>
                                    <p className="text-[10px] text-slate-500 tracking-wide mt-0.5 truncate max-w-[140px] sm:max-w-[200px]">
                                      {st.name}
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="p-4 text-right font-mono font-bold text-slate-200">
                                ₹{st.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                              </td>
                              <td className={`p-4 text-right font-mono font-bold ${
                                isPositive ? 'text-emerald-400' : 'text-red-400'
                              }`}>
                                {isPositive ? '+' : ''}{valChangePercent}%
                              </td>
                              <td className="p-4 hidden sm:table-cell">
                                {isFandoLocked ? (
                                  <span className="px-2 py-0.5 bg-red-950/50 text-red-400 text-[9px] font-extrabold rounded-full border border-red-500/20 uppercase tracking-widest flex items-center gap-1 w-fit">
                                    <Lock className="w-2.5 h-2.5" /> locked for safety
                                  </span>
                                ) : st.riskRating === 'Low' ? (
                                  <span className="px-2 py-0.5 bg-indigo-900/30 text-indigo-400 text-[9px] font-extrabold rounded-full border border-indigo-400/20 uppercase tracking-widest">
                                    Bluechip Safe
                                  </span>
                                ) : st.riskRating === 'Medium' ? (
                                  <span className="px-2 py-0.5 bg-yellow-900/20 text-yellow-500 text-[9px] font-extrabold rounded-full border border-yellow-500/20 uppercase tracking-widest">
                                    Moderate Risk
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-red-950/30 text-red-500 text-[9px] font-extrabold rounded-full border border-red-500/25 uppercase tracking-widest">
                                    High leverage option
                                  </span>
                                )}
                              </td>
                              <td className="p-4 text-center">
                                <button className="bg-indigo-650 hover:bg-indigo-700 hover:text-white text-slate-200 font-bold px-3 py-1.5 rounded text-[10px] uppercase cursor-pointer">
                                  Trade
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Right Column: Dynamic Interactive chart & place-order ticketing terminal pane */}
                <div id="quick-order-pane" className="space-y-6">
                  
                  {/* Stock Mini-Details Card */}
                  <div className="bg-slate-905 bg-[#141d2e] rounded-2xl border border-slate-800 p-5 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-widest font-mono">{selectedStock.sector}</span>
                        <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2 mt-0.5">
                          {selectedStock.symbol}
                          <span className="text-xs text-slate-400 font-normal">{selectedStock.name}</span>
                        </h3>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-mono font-bold text-white">₹{selectedStock.price}</p>
                        <p className={`text-xs font-semibold ${selectedStock.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {selectedStock.change >= 0 ? '+' : ''}{selectedStock.change} ({selectedStock.changePercent}%)
                        </p>
                      </div>
                    </div>

                    {/* Premium AI Recommendation Preview */}
                    <div className="p-3 bg-slate-900 rounded-xl border border-slate-800/80 space-y-1.5">
                      <p className="text-[10px] font-bold tracking-wider text-slate-400 uppercase flex items-center gap-1">
                        <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                        <span>InvestAI Rating Guide</span>
                      </p>
                      <p className="text-[11px] text-slate-300 leading-snug italic font-medium">
                        "{selectedStock.aiRecommendation}"
                      </p>
                      <div className="flex items-center justify-between text-[11px] mt-1 text-slate-500 font-semibold pt-1 border-t border-slate-800">
                        <span>AI Tech Confidence Score:</span>
                        <span className="font-bold text-indigo-400 font-mono">{selectedStock.aiScore}/100</span>
                      </div>
                    </div>

                    {/* Simple Custom SVG responsive Chart */}
                    <div className="h-44 bg-slate-950 rounded-xl border border-slate-850 relative flex items-end overflow-hidden p-1">
                      {/* Grid background lines */}
                      <div className="absolute inset-x-0 top-1/4 border-b border-slate-900/60"></div>
                      <div className="absolute inset-x-0 top-2/4 border-b border-slate-900/60"></div>
                      <div className="absolute inset-x-0 top-3/4 border-b border-slate-900/60"></div>

                      <div className="absolute inset-0 p-3 flex flex-col justify-between pointer-events-none">
                        <span className="text-[9px] font-extrabold text-slate-600 font-mono">HIGH: ₹{selectedStock.high}</span>
                        <span className="text-[9px] font-extrabold text-slate-600 font-mono self-end">LOW: ₹{selectedStock.low}</span>
                      </div>

                      {/* SVG path mapping */}
                      <svg viewBox="0 0 100 100" className="w-full h-[80%] absolute bottom-2 overflow-visible">
                        <defs>
                          <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.3"/>
                            <stop offset="100%" stopColor="#1e1b4b" stopOpacity="0"/>
                          </linearGradient>
                        </defs>
                        
                        {/* Area Gradient path */}
                        <path
                          d={`M 0,100 L 
                            ${selectedStock.historicalData.map((d, i) => {
                              const ratio = (d.price - selectedStock.low) / Math.max(1, (selectedStock.high - selectedStock.low));
                              const y = 90 - (ratio * 80);
                              const x = (i / (selectedStock.historicalData.length - 1)) * 100;
                              return `${x},${y}`;
                            }).join(' L ')} 
                            L 100,100 Z`}
                          fill="url(#chartGrad)"
                        />

                        {/* Trend Stroke line */}
                        <path
                          d={selectedStock.historicalData.map((d, i) => {
                            const ratio = (d.price - selectedStock.low) / Math.max(1, (selectedStock.high - selectedStock.low));
                            const y = 90 - (ratio * 80);
                            const x = (i / (selectedStock.historicalData.length - 1)) * 100;
                            return `${i === 0 ? 'M' : 'L'} ${x},${y}`;
                          }).join(' ')}
                          fill="none"
                          stroke={selectedStock.changePercent >= 0 ? '#10b981' : '#f43f5e'}
                          strokeWidth="2"
                        />
                      </svg>
                      <p className="absolute bottom-1 right-2 text-[8px] font-mono text-slate-500 uppercase tracking-wider">Previous 30 Days trend</p>
                    </div>

                    {/* Quick Order Form */}
                    <form onSubmit={handlePlaceOrder} className="space-y-3.5">
                      <div className="grid grid-cols-2 gap-2 p-0.5 bg-slate-900 rounded-lg">
                        <button
                          type="button"
                          onClick={() => setTradeType('BUY')}
                          className={`py-2 text-xs font-bold rounded cursor-pointer uppercase transition-colors ${
                            tradeType === 'BUY' 
                              ? 'bg-emerald-650 text-white shadow-md' 
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {t.buy}
                        </button>
                        <button
                          type="button"
                          onClick={() => setTradeType('SELL')}
                          className={`py-2 text-xs font-bold rounded cursor-pointer uppercase transition-all ${
                            tradeType === 'SELL' 
                              ? 'bg-rose-650 text-white shadow-md' 
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {t.sell}
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">{t.orderType}</label>
                          <select
                            value={orderType}
                            onChange={(e) => setOrderType(e.target.value as any)}
                            className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white text-xs"
                          >
                            <option value="MARKET">MARKET</option>
                            <option value="LIMIT">LIMIT ORDER</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
                            {orderType === 'MARKET' ? 'Market price (₹)' : t.limitPrice}
                          </label>
                          <input
                            type="number"
                            disabled={orderType === 'MARKET'}
                            value={orderType === 'MARKET' ? selectedStock.price : limitPriceInput}
                            onChange={(e) => setLimitPriceInput(parseFloat(e.target.value))}
                            className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono text-xs"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 items-center">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">{t.quantity}</label>
                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={tradeQuantity}
                            onChange={(e) => setTradeQuantity(parseInt(e.target.value) || 0)}
                            className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-white font-mono text-xs"
                          />
                        </div>

                        <div className="text-right">
                          <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">{t.totalCost}</p>
                          <p className="text-sm font-bold font-mono text-white">
                            ₹{(tradeQuantity * (orderType === 'MARKET' ? selectedStock.price : limitPriceInput)).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                          </p>
                        </div>
                      </div>

                      {orderMessage && (
                        <div className={`p-2.5 rounded-lg text-xs leading-relaxed border ${
                          orderMessage.isError 
                            ? 'bg-rose-950/20 border-rose-900/40 text-rose-300' 
                            : 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300'
                        }`}>
                          {orderMessage.isError ? '⚠️ ' : '✅ '}
                          {orderMessage.text}
                        </div>
                      )}

                      {/* Display F&O restrictions directly on button if relevant */}
                      {selectedStock.segment === 'fando' && !profile.unlockedInstruments.fAndO && profile.persona === 'beginner' ? (
                        <button
                          type="button"
                          onClick={() => {
                            setOrderMessage({
                              text: TRANSLATIONS[profile.language].fandoLockedMsg,
                              isError: true
                            });
                          }}
                          className="w-full py-3 bg-slate-850 text-slate-500 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 border border-slate-800/80 cursor-not-allowed"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>{t.locked}</span>
                        </button>
                      ) : (
                        <button
                          type="submit"
                          className="w-full py-3 bg-indigo-650 hover:bg-indigo-700 hover:text-white text-slate-100 rounded-xl font-bold text-xs uppercase tracking-widest transition-all cursor-pointer shadow-lg shadow-indigo-950"
                        >
                          {t.placeBtn}
                        </button>
                      )}
                    </form>
                  </div>

                </div>

              </div>
              
              {/* Active simulated Holdings and Order status cards */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-12">
                
                {/* Simulated Holdings / Portfolio Position tracker */}
                <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-lg min-h-[220px]">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                    <h3 className="font-bold text-sm text-white flex items-center gap-2">
                      <Coins className="w-4 h-4 text-slate-400" />
                      <span>Active Practice Positions ({holdings.length})</span>
                    </h3>
                    <p className="text-xs text-slate-400">Total invested: ₹{totalHoldingsCost.toLocaleString('en-IN')}</p>
                  </div>

                  {holdings.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-500">
                      You do not have any open positions in this training account. Place standard buy orders above!
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="text-slate-500 font-bold border-b border-slate-800 uppercase tracking-widest text-[9px]">
                            <th className="py-2">Holding</th>
                            <th className="py-2 text-right">Avg Buy (₹)</th>
                            <th className="py-2 text-right">Qty</th>
                            <th className="py-2 text-right">Current Value (₹)</th>
                            <th className="py-2 text-right">Returns</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/40">
                          {holdings.map((h, i) => {
                            const curValue = h.quantity * h.currentPrice;
                            const totalCost = h.quantity * h.avgPrice;
                            const profitAmt = curValue - totalCost;
                            const profitPct = totalCost > 0 ? (profitAmt / totalCost) * 100 : 0;
                            return (
                              <tr key={i} className="hover:bg-slate-950/20">
                                <td className="py-3 font-bold text-slate-300">{h.symbol}</td>
                                <td className="py-3 text-right font-mono text-slate-400">₹{h.avgPrice}</td>
                                <td className="py-3 text-right font-mono text-slate-300">{h.quantity}</td>
                                <td className="py-3 text-right font-mono text-slate-300">₹{curValue.toFixed(2)}</td>
                                <td className={`py-3 text-right font-mono font-bold ${
                                  profitAmt >= 0 ? 'text-emerald-400' : 'text-rose-400'
                                }`}>
                                  {profitAmt >= 0 ? '+' : ''}{profitAmt.toFixed(1)} ({profitPct.toFixed(1)}%)
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Real-time Order Receipts tracker */}
                <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-lg min-h-[220px]">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                    <h3 className="font-bold text-sm text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-slate-400" />
                      <span>Order Book Signal Ledger ({orders.length})</span>
                    </h3>
                    <button 
                      onClick={() => {
                        setOrders([]);
                        localStorage.removeItem('team_invest_orders');
                      }}
                      className="text-[9px] uppercase tracking-wider font-bold text-red-400 hover:underline cursor-pointer"
                    >
                      Clear Log
                    </button>
                  </div>

                  {orders.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-500">
                      No transactions have been placed in this trading session. All buys/sells log instant receipts here.
                    </div>
                  ) : (
                    <div className="overflow-y-auto max-h-40 divide-y divide-slate-800/40">
                      {orders.map((ord, i) => (
                        <div key={i} className="py-2.5 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-extrabold text-slate-200">
                              <span className={`inline-block w-1.5 h-1.5 rounded-full mr-2 ${ord.type === 'BUY' ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                              {ord.type} {ord.symbol}
                            </p>
                            <p className="text-[10px] text-slate-500 mt-0.5 font-semibold">
                              {ord.quantity} share(s) via {ord.orderType} • {ord.timestamp}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-mono font-semibold text-slate-300">₹{(ord.price * ord.quantity).toLocaleString()}</p>
                            <span className="text-[9px] bg-indigo-950/20 text-indigo-400 border border-indigo-900/60 font-bold px-1.5 py-0.25 rounded uppercase">
                              {ord.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>

            </div>
          )}

          {/* 2. Gamified Practice Simulator Track */}
          {activeTab === 'simulator' && (
            <div className="space-y-6 max-w-4xl">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-lg text-left">
                <span className="text-[10px] font-bold text-indigo-400 tracking-widest uppercase">Safe Practice Arena</span>
                <h2 className="text-2xl font-bold text-white tracking-tight">Interactive Local Simulator Practice</h2>
                
                <p className="text-sm text-slate-300 leading-relaxed">
                  Avoid paying high brokerages or losing real money in complex derivative contracts. Team Invest provides a fully populated real-time simulated sandbox with <b>₹{profile.simulatedBalance.toLocaleString()}</b> practice currency which fluctuates in line with simulated live stock pricing.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
                    <span className="text-[9px] font-extrabold text-slate-500 tracking-wide uppercase">Interactive Balance</span>
                    <p className="text-2xl font-mono font-bold text-indigo-400 mt-1">₹{profile.simulatedBalance.toLocaleString()}</p>
                    <p className="text-[10px] text-slate-500 mt-1">Risk-free practicing cash</p>
                  </div>
                  
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
                    <span className="text-[9px] font-extrabold text-slate-500 tracking-wide uppercase">Mock Trades Completed</span>
                    <p className="text-2xl font-mono font-bold text-emerald-400 mt-1">{profile.milestones.completedMockTrades}</p>
                    <p className="text-[10px] text-slate-500 mt-1">Required to unlock F&O: 3</p>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
                    <span className="text-[9px] font-extrabold text-slate-500 tracking-wide uppercase">Open Stock Positions</span>
                    <p className="text-2xl font-mono font-bold text-teal-400 mt-1">{holdings.length}</p>
                    <p className="text-[10px] text-slate-500 mt-1">Invested: ₹{totalHoldingsValue.toLocaleString()}</p>
                  </div>
                </div>

                <div className="p-4 bg-indigo-950/20 border border-indigo-900/40 rounded-xl mt-4 flex items-center justify-between text-xs">
                  <span className="text-indigo-200">Want to test your strategy on different stock symbols instead?</span>
                  <button 
                    onClick={() => {
                      setActiveTab('terminal');
                      setOrderMessage(null);
                    }}
                    className="bg-indigo-650 hover:bg-indigo-700 text-white font-bold px-4 py-2 rounded-lg cursor-pointer"
                  >
                    Go Trade Live stocks &rarr;
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 3. Academy / Learning Hub */}
          {activeTab === 'learning' && (
            <div className="space-y-6 max-w-4xl text-left">
              
              {/* Academy progress details header card */}
              <div className="bg-indigo-900/10 border border-indigo-500/20 rounded-2xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <span className="text-[10px] font-extrabold text-indigo-400 tracking-widest uppercase">Safe Onboarding Academy</span>
                    <h2 className="text-2xl font-bold text-white mt-1">Interactive Trading Milestones</h2>
                    <p className="text-xs text-indigo-300 mt-1 leading-relaxed">
                      Complete learning modules and execute safe simulator trades. Once all milestones are green, unlock high-risk F&O derivative contracts.
                    </p>
                  </div>

                  <div className="shrink-0 bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-center w-full sm:w-48">
                    <p className="text-2xl font-bold font-mono text-indigo-400">
                      {Math.round(((lessonsCompleted.length + Math.min(3, profile.milestones.completedMockTrades)) / 6) * 100)}%
                    </p>
                    <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest mt-1">Overall unlocked progress</p>
                  </div>
                </div>

                {/* Milestone Checklist Indicators */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                  <div className="space-y-2">
                    <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Required Safety checkpoints</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center gap-2">
                        {lessonsCompleted.length >= 3 ? (
                          <CheckCircle className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <span className="w-4 h-4 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-500">1</span>
                        )}
                        <span className="text-slate-300">Read 3 basic derivative modules ({lessonsCompleted.length}/3)</span>
                      </div>

                      <div className="flex items-center gap-2">
                        {profile.milestones.completedMockTrades >= 3 ? (
                          <CheckCircle className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <span className="w-4 h-4 rounded-full border border-slate-700 flex items-center justify-center text-[10px] text-slate-500">2</span>
                        )}
                        <span className="text-slate-300">Execute 3 mock test trades ({Math.min(3, profile.milestones.completedMockTrades)}/3)</span>
                      </div>
                    </div>
                  </div>

                  {/* Ready to Unlock or state box */}
                  <div className="flex flex-col justify-center">
                    {profile.unlockedInstruments.fAndO ? (
                      <div className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-emerald-400" />
                        <span>F&O Derivatives Segment is Unlocked! You have advanced trader status.</span>
                      </div>
                    ) : (lessonsCompleted.length >= 3 && profile.milestones.completedMockTrades >= 3) ? (
                      <button
                        onClick={handleUnlockFAndOSafely}
                        className="w-full py-3 bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-700 hover:to-indigo-700 text-white font-extrabold rounded-xl text-xs uppercase tracking-widest cursor-pointer shadow-lg animate-bounce transition-all text-center"
                      >
                        🎓 UNLOCK F&O DERIVATIVES NOW
                      </button>
                    ) : (
                      <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-850/80 text-xs text-slate-400 flex items-center gap-2">
                        <Lock className="w-4 h-4 text-slate-500 shrink-0" />
                        <span>Finish modules and 3 simulator trades to activate the unlock.</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Lesson Modules cards list */}
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-slate-300 tracking-wide">Interactive SEBI-Aligned Lessons</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Lesson 1 */}
                  <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] bg-slate-800 text-slate-400 font-mono px-2 py-0.5 rounded">Module 1</span>
                      <h4 className="font-semibold text-xs text-white mt-1.5 leading-snug">The Mechanics of Short Selling & Derivatives Leverage</h4>
                      <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                        Learn how derivatives derive valuation. Leverage allows trading up to 10x capital, meaning a tiny 5% price shift can completely wipe out your premium deposit!
                      </p>
                    </div>
                    <button
                      onClick={() => handleToggleLesson('les-1')}
                      className={`w-full py-2 rounded text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                        lessonsCompleted.includes('les-1')
                          ? 'bg-emerald-950/20 text-emerald-400 border border-emerald-900/40'
                          : 'bg-indigo-650 text-white hover:bg-indigo-750'
                      }`}
                    >
                      {lessonsCompleted.includes('les-1') ? '✓ Read Completed' : 'Read Lesson'}
                    </button>
                  </div>

                  {/* Lesson 2 */}
                  <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] bg-slate-800 text-slate-400 font-mono px-2 py-0.5 rounded">Module 2</span>
                      <h4 className="font-semibold text-xs text-white mt-1.5 leading-snug">Managing Drawdown Risk & Margin Calls</h4>
                      <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                        Brokers auto-square positions of investors if margin rules fail in intraday trading. We explain how stops work to save beginners from massive account deficits.
                      </p>
                    </div>
                    <button
                      onClick={() => handleToggleLesson('les-2')}
                      className={`w-full py-2 rounded text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                        lessonsCompleted.includes('les-2')
                          ? 'bg-emerald-950/20 text-emerald-400 border border-emerald-900/40'
                          : 'bg-indigo-650 text-white hover:bg-indigo-750'
                      }`}
                    >
                      {lessonsCompleted.includes('les-2') ? '✓ Read Completed' : 'Read Lesson'}
                    </button>
                  </div>

                  {/* Lesson 3 */}
                  <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] bg-slate-800 text-slate-400 font-mono px-2 py-0.5 rounded">Module 3</span>
                      <h4 className="font-semibold text-xs text-white mt-1.5 leading-snug">Options Expiry & Theta Time Decay</h4>
                      <p className="text-[11px] text-slate-400 mt-2 leading-relaxed">
                        Options lose value every night through Theta decay, which accelerates on weekly expiry days. 95% of active retail option buyers end in overall losses.
                      </p>
                    </div>
                    <button
                      onClick={() => handleToggleLesson('les-3')}
                      className={`w-full py-2 rounded text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                        lessonsCompleted.includes('les-3')
                          ? 'bg-emerald-950/20 text-emerald-400 border border-emerald-900/40'
                          : 'bg-indigo-650 text-white hover:bg-indigo-750'
                      }`}
                    >
                      {lessonsCompleted.includes('les-3') ? '✓ Read Completed' : 'Read Lesson'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Academy mini quiz card */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
                <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase">Academy mini logic check</span>
                <h4 className="font-bold text-white text-sm">Under Section 5.1 of Indian SEBI Investor Laws, what is maximum recommended F&O risk capital?</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <button 
                    onClick={() => { setLearningQuizScore(0); setShowLearningFeedback(true); }}
                    className="p-3 bg-slate-950 border border-slate-850 rounded-xl hover:border-indigo-500 cursor-pointer text-left text-slate-300 transition-colors"
                  >
                    100% of my total retirement savings
                  </button>
                  <button 
                    onClick={() => { setLearningQuizScore(100); setShowLearningFeedback(true); }}
                    className="p-3 bg-slate-950 border border-slate-850 rounded-xl hover:border-indigo-500 cursor-pointer text-left text-slate-300 transition-colors"
                  >
                    Maximum 10% of disposable risk income
                  </button>
                  <button 
                    onClick={() => { setLearningQuizScore(0); setShowLearningFeedback(true); }}
                    className="p-3 bg-slate-950 border border-slate-850 rounded-xl hover:border-indigo-500 cursor-pointer text-left text-slate-300 transition-colors"
                  >
                    Borrowed cash using gold or house financing
                  </button>
                </div>
                {showLearningFeedback && (
                  <div className={`p-4 rounded-xl text-xs border ${
                    learningQuizScore === 100 
                      ? 'bg-emerald-950/30 border-emerald-900/40 text-emerald-300' 
                      : 'bg-rose-950/30 border-rose-900/40 text-rose-300'
                  }`}>
                    {learningQuizScore === 100 
                      ? '✓ Excellent correct answer! SEBI recommends allocating no more than 10% of standard capital holdings specifically towards derivative speculation.' 
                      : '❌ Highly Risky Strategy. Allocating more than 10% or using borrowed margins sets beginners up for default situations quickly.'}
                  </div>
                )}
              </div>

            </div>
          )}

          {/* 4. Premium Advanced View */}
          {activeTab === 'premium' && (
            <div className="space-y-6 max-w-4xl text-left">
              
              {/* Backtesting Strategy Engine Panel */}
              <div id="premium-backtester" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
                <div className="flex items-center gap-2 mb-1">
                  <div className="bg-indigo-505/20 text-indigo-400 p-1.5 rounded-lg">
                    <Cpu className="w-5 h-5 text-indigo-400 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white leading-none">{t.backtestTitle}</h3>
                    <p className="text-xs text-slate-400 mt-1">{t.backtestExpl}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1 text-xs">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Stock Ticker Symbol</label>
                    <select
                      value={backtestStock}
                      onChange={(e) => setBacktestStock(e.target.value)}
                      className="w-full bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-white font-bold"
                    >
                      {stocks.filter(s => s.segment === 'equity').map(s => (
                        <option key={s.symbol} value={s.symbol}>{s.symbol}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">{t.smaShort}</label>
                    <input
                      type="number"
                      min="2"
                      max="10"
                      value={backtestShortMA}
                      onChange={(e) => setBacktestShortMA(parseInt(e.target.value) || 5)}
                      className="w-full bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">{t.smaLong}</label>
                    <input
                      type="number"
                      min="11"
                      max="25"
                      value={backtestLongMA}
                      onChange={(e) => setBacktestLongMA(parseInt(e.target.value) || 20)}
                      className="w-full bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Initial Capital (₹)</label>
                    <input
                      type="number"
                      step="10000"
                      value={backtestCapital}
                      onChange={(e) => setBacktestCapital(parseInt(e.target.value) || 100000)}
                      className="w-full bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-white font-mono"
                    />
                  </div>
                </div>

                <button
                  onClick={handleExecuteBacktest}
                  disabled={isBacktestingLoading}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-extrabold rounded-xl text-xs uppercase tracking-wider cursor-pointer shadow transition-all"
                >
                  {isBacktestingLoading ? 'Backtesting engine calculation active...' : t.runBacktest}
                </button>

                {backtestResult && (
                  <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                      <div>
                        <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">{t.backtestProfit}</p>
                        <p className={`text-xl font-mono font-black mt-1 ${backtestResult.netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {backtestResult.netProfitPercent}%
                          <span className="text-xs font-semibold block">₹{backtestResult.netProfit.toLocaleString('en-IN')}</span>
                        </p>
                      </div>

                      <div>
                        <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">{t.totalTrades}</p>
                        <p className="text-xl font-mono font-bold text-indigo-400 mt-1">{backtestResult.totalTrades}</p>
                      </div>

                      <div>
                        <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">{t.winRate}</p>
                        <p className="text-xl font-mono font-bold text-emerald-300 mt-1">{backtestResult.winRate}%</p>
                      </div>

                      <div>
                        <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest">Ending Capital Value</p>
                        <p className="text-xl font-mono font-bold text-slate-200 mt-1">₹{backtestResult.finalValue.toLocaleString('en-IN')}</p>
                      </div>
                    </div>

                    {/* Backtest equity curve */}
                    <div className="h-28 flex items-end justify-between gap-1 pt-6 border-t border-slate-900">
                      {backtestResult.chartData.map((d, i) => {
                        const maxVal = Math.max(...backtestResult.chartData.map(cd => cd.equity));
                        const minVal = Math.min(...backtestResult.chartData.map(cd => cd.equity));
                        const span = Math.max(1, maxVal - minVal);
                        const ratio = (d.equity - minVal) / span;
                        const heightPct = 20 + ratio * 80;

                        return (
                          <div key={i} className="flex-1 flex flex-col items-center group relative cursor-pointer">
                            <div 
                              style={{ height: `${heightPct}%` }}
                              className={`w-full rounded-t ${d.equity >= backtestResult.initialCapital ? 'bg-indigo-650' : 'bg-indigo-950'} group-hover:bg-indigo-500 transition-all`}
                            ></div>
                            <span className="text-[8px] font-mono text-slate-500 mt-1.5 rotate-45">{d.date}</span>

                            {/* tooltip */}
                            <div className="absolute bottom-full mb-1 bg-slate-900 border border-slate-800 rounded p-1 text-[9px] text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
                              ₹{d.equity.toLocaleString('en-IN')} • {d.close} INR
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Indian Capital Gains Advisor Tax Estimator card */}
              <div id="premium-tax-estimator" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Calculator className="w-5 h-5 text-indigo-400" />
                  <h3 className="text-md font-bold text-slate-200">{t.taxAdvisor}</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Estimated Net Realized Capital gains profit (₹)</label>
                      <input
                        type="number"
                        step="5000"
                        value={taxProfits}
                        onChange={(e) => setTaxProfits(parseInt(e.target.value) || 0)}
                        className="w-full bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-500 mb-1">Stock Holding Period</label>
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => setTaxHoldingPeriod('short_term')}
                          className={`py-2 px-3 rounded-lg border font-bold text-xs cursor-pointer ${
                            taxHoldingPeriod === 'short_term'
                              ? 'bg-indigo-650 text-white border-indigo-500'
                              : 'bg-slate-950 text-slate-400 border-slate-800'
                          }`}
                        >
                          Short Term (&lt; 1 Year)
                        </button>
                        <button
                          type="button"
                          onClick={() => setTaxHoldingPeriod('long_term')}
                          className={`py-2 px-3 rounded-lg border font-bold text-xs cursor-pointer ${
                            taxHoldingPeriod === 'long_term'
                              ? 'bg-indigo-650 text-white border-indigo-500'
                              : 'bg-slate-950 text-slate-400 border-slate-800'
                          }`}
                        >
                          Long Term (&gt; 1 Year)
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Calculated Results right side */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3.5">
                    <h4 className="text-[10px] uppercase font-semibold text-slate-500 tracking-wider">Breakdown of Taxes under Indian Law</h4>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-medium">Estimated STCG (15% Tax):</span>
                        <span className="font-mono font-bold text-white">₹{calcStcg.toLocaleString('en-IN')}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-medium">Estimated LTCG (10% over 1.25L exemption):</span>
                        <span className="font-mono font-bold text-white">
                          {taxProfits > 125000 ? `₹${calcLtcg.toLocaleString('en-IN')}` : '₹0 (Under 1.25 Lakh threshold)'}
                        </span>
                      </div>

                      <div className="border-t border-slate-900 pt-2 flex justify-between font-bold text-indigo-300">
                        <span>Total Projected tax due:</span>
                        <span className="font-mono text-xs">
                          ₹{(taxHoldingPeriod === 'short_term' ? calcStcg : calcLtcg).toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-500 leading-normal">
                      Note: Calculated on the standard Indian Capital Gains Tax laws for FY 2026. Standard 4% health & education cess will be added on final assessments.
                    </p>
                  </div>
                </div>
              </div>

              {/* AI Advisory Section alerts */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow-lg">
                <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase">{t.advisoryAlerts}</span>
                
                <div className="space-y-2.5">
                  {[
                    { headline: 'HDFC Bank Merger Convergence', text: 'Merger costs digested. Credit deposit ratios consolidating beautifully with stable margins (AI rating: 84/100 buy opportunity).', date: 'Today' },
                    { headline: 'IT Sector Momentum on Cloud spends', text: 'Global enterprises accelerating digital spend pipelines. High visibility expected in INFY and TCS Q1 results (low volatility risk rating).', date: 'Yesterday' }
                  ].map((adv, i) => (
                    <div key={i} className="p-3 bg-slate-950 rounded-xl border border-slate-850 flex items-start gap-3">
                      <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 shrink-0 mt-1.5 animate-pulse"></div>
                      <div className="space-y-0.5">
                        <p className="text-xs font-bold text-slate-200">{adv.headline}</p>
                        <p className="text-[11px] text-slate-400 leading-relaxed italic">"{adv.text}"</p>
                        <p className="text-[9px] text-slate-500 mt-1">{adv.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* 5. Qualitative Feedback box Tab */}
          {activeTab === 'feedback' && (
            <div className="space-y-6 max-w-xl text-left">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4 shadow-lg">
                <div>
                  <span className="text-[10px] font-bold text-indigo-300 tracking-widest uppercase">Team Invest MVP evaluation</span>
                  <h2 className="text-xl font-bold text-white mt-1">{t.feedbackTitle}</h2>
                  <p className="text-xs text-slate-400 mt-1">{t.feedbackSub}</p>
                </div>

                {submissionCompleted ? (
                  <div className="p-4 bg-emerald-950/20 border border-emerald-900/40 text-emerald-300 rounded-xl text-xs space-y-2 text-center animate-fade-in">
                    <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
                    <p className="font-bold">{t.feedbackSuccess}</p>
                    <button
                      onClick={() => setSubmissionCompleted(false)}
                      className="text-xs text-indigo-400 hover:underline mt-2 inline-block font-semibold"
                    >
                      Submit another suggestion
                    </button>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      setSubmissionCompleted(true);
                    }}
                    className="space-y-4 text-xs font-sans"
                  >
                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5Label">
                        {t.feedbackLanguageOk} ({t.feedbackLanguageLabel})
                      </label>
                      <select
                        value={qualitativeForm.translationScore}
                        onChange={(e) => setQualitativeForm(prev => ({ ...prev, translationScore: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                      >
                        <option value="natural">Perfect, highly natural and grammatical</option>
                        <option value="needs_work">Grammar is correct, but needs colloquial refinement</option>
                        <option value="broken">Contains machine-translation errors</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5">
                        {t.feedbackUsageOk} ({t.feedbackUsageLabel})
                      </label>
                      <select
                        value={qualitativeForm.onboardingGrade}
                        onChange={(e) => setQualitativeForm(prev => ({ ...prev, onboardingGrade: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-white"
                      >
                        <option value="helpful">Very helpful, locks high risk for safe learning</option>
                        <option value="annoying">Slightly tedious but improves awareness</option>
                        <option value="unnecessary">Prefer instant raw access directly</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5 col-span-1 border-b py-1">
                        {t.feedbackFeatureReq}
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-1">
                        {[
                          { id: 'tax_planning', label: 'Advanced Tax planning' },
                          { id: 'live_options_chart', label: 'Options Option Gearing chart' },
                          { id: 'ai_robo_advisor', label: 'Automated AI Robo advice' }
                        ].map(feature => (
                          <button
                            key={feature.id}
                            type="button"
                            onClick={() => setQualitativeForm(prev => ({ ...prev, requestTool: feature.id }))}
                            className={`p-2 rounded-lg text-xs border cursor-pointer ${
                              qualitativeForm.requestTool === feature.id
                                ? 'bg-indigo-650 border-indigo-500 text-white'
                                : 'bg-slate-950 border-slate-850 text-slate-400'
                            }`}
                          >
                            {feature.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5">
                        Specific suggestions or feature comments
                      </label>
                      <textarea
                        rows={3}
                        value={qualitativeForm.userComments}
                        onChange={(e) => setQualitativeForm(prev => ({ ...prev, userComments: e.target.value }))}
                        placeholder="I would love custom SEBI regulatory summary alerts on margin squaring..."
                        className="w-full bg-slate-950 border border-slate-850 rounded-lg p-2.5 text-white placeholder-slate-600 focus:outline-none"
                      ></textarea>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs uppercase tracking-widest cursor-pointer shadow-lg hover:shadow-indigo-950/45 transition-all text-center"
                    >
                      {t.submitBtn}
                    </button>
                  </form>
                )}
              </div>

              {/* Developer administration helpers */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 shadow">
                <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase">Administrative resets</span>
                <p className="text-xs text-slate-400">Clear cached data or switch profile tracks back to the beginning easily.</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleResetSession}
                    className="px-4 py-2 bg-slate-800 hover:bg-red-950/40 text-xs font-bold rounded-lg text-[10px] uppercase cursor-pointer"
                  >
                    Reset & Restart Onboarding Safe Protocol &rarr;
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Persistent Floating Chatbot panel */}
      <Chatbot language={profile.language} />

      {/* Global Regulatory Footer */}
      <footer className="h-10 bg-slate-950 border-t border-slate-900 flex items-center justify-center px-4">
        <p className="text-[10px] text-slate-500 text-center select-none truncate">
          🔔 Real-Time Stock prices are simulated for learning purposes. Investment in securities carries risk • Team Invest MVP 2026
        </p>
      </footer>
    </div>
  );
}
