import { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, AlertTriangle, Sparkles } from 'lucide-react';
import { ChatMessage, Language } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface ChatbotProps {
  language: Language;
}

export default function Chatbot({ language }: ChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'default-1',
      role: 'model',
      text: language === 'hi' 
        ? 'प्रणाम! मैं टीम इन्वेस्ट एआई मार्गदर्शक हूँ। स्टॉक, ऑप्शन ट्रेडिंग रिस्क, या वित्तीय शब्दावली के बारे में कुछ भी पूछें!' 
        : language === 'ta'
        ? 'வணக்கம்! நான் டீம் இன்வெஸ்ட் ஏஐ உதவியாளர். ஆப்ஷன்ஸ் ஆபத்துக்கள் மற்றும் பங்குகள் பற்றி என்னிடம் கேளுங்கள்!'
        : 'Hello! I am your Team Invest AI guide. Ask me about stocks, F&O safety, or Indian financial terms!',
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const t = TRANSLATIONS[language];

  // Quick prompt suggestions
  const suggestions = {
    en: [
      'Explain F&O in simple terms',
      'What are Indian Short Term Capital Gains?',
      'Analyze Reliance Industries risk'
    ],
    hi: [
      'सरल शब्दों में F&O क्या है?',
      'अल्पकालिक पूंजीगत लाभ (STCG) क्या है?',
      'रिलायंस का जोखिम स्तर बताएं'
    ],
    ta: [
      'எளிய முறையில் F&O என்றால் என்ன?',
      'குறுகிய கால மூலதன ஆதாயம் (STCG) என்றால் என்ன?',
      'ரிலையன்ஸ் பங்கின் ஆபத்து என்ன?'
    ]
  }[language];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          language
        })
      });

      const data = await response.json();
      
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        text: data.text || 'Unable to generate response. Try checking your internet connection.',
        timestamp: new Date().toLocaleTimeString()
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      console.error(error);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: 'The AI service could not be contacted. (Mock Simulation mode activated under network issues)',
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="ai_chatbot_root" className="fixed bottom-6 right-6 z-50 font-sans">
      {/* Floating Toggle Icon */}
      {!isOpen && (
        <button
          id="chatbot_toggle_btn"
          onClick={() => setIsOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-4 shadow-xl flex items-center gap-2 animate-bounce cursor-pointer transition-colors"
        >
          <MessageSquare className="w-6 h-6" />
          <span className="text-sm font-medium hidden md:inline-block">
            {t.botHealth}
          </span>
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div
          id="chatbot_window"
          className="bg-[#1e293b] border border-slate-700 text-slate-100 rounded-2xl w-80 sm:w-96 h-[500px] flex flex-col shadow-2xl overflow-hidden backdrop-blur-md"
        >
          {/* Header */}
          <div className="bg-slate-800 p-4 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="bg-indigo-505/20 text-indigo-400 p-1.5 rounded-lg flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <h3 className="font-semibold text-sm text-white">Team Invest AI Assistant</h3>
                <p className="text-xs text-emerald-400 flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 inline-block"></span>
                  {t.botHealth} (Gemini)
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Attention / Hazard warning */}
          <div className="bg-amber-950/40 px-3 py-2 border-b border-amber-800/40 text-[11px] text-amber-200 flex items-start gap-1.5">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
            <span>
              {t.riskWarning}
            </span>
          </div>

          {/* Messages */}
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-800"
          >
            {messages.map(msg => (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[80%] ${
                  msg.role === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
                }`}
              >
                <div
                  className={`p-3 rounded-2xl text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-indigo-600 text-white rounded-tr-none'
                      : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700'
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}
            {isLoading && (
              <div className="flex items-center gap-1.5 text-xs text-slate-400 p-2">
                <span className="animate-ping h-2.5 w-2.5 rounded-full bg-indigo-500 inline-block"></span>
                <span>AI Typing...</span>
              </div>
            )}
          </div>

          {/* Suggestions */}
          <div className="p-2 border-t border-slate-700 bg-slate-900/50 space-y-1">
            <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500 px-1">
              Suggestions
            </p>
            <div className="flex flex-wrap gap-1">
              {suggestions.map((sug, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(sug)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[11px] px-2.5 py-1 text-left w-full truncate border border-slate-700/50 transition-colors"
                >
                  {sug}
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputMessage);
            }}
            className="p-3 bg-slate-800 border-t border-slate-700 flex gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={t.botPlaceholder}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 placeholder-slate-500"
            />
            <button
              type="submit"
              disabled={isLoading || !inputMessage.trim()}
              className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl p-2 flex items-center justify-center cursor-pointer min-w-9"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
