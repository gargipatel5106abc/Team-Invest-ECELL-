import { StockData } from '../types';

export const INITIAL_STOCKS: StockData[] = [
  {
    symbol: 'RELIANCE',
    name: 'Reliance Industries Ltd.',
    segment: 'equity',
    price: 2450.50,
    change: 15.20,
    changePercent: 0.62,
    high: 2475.00,
    low: 2432.10,
    open: 2435.30,
    volume: 5200000,
    sector: 'Conglomerate / Energy',
    description: 'India\'s largest private sector corporation with diversified businesses in energy, retail, telecom, and digital services.',
    riskRating: 'Medium',
    aiRecommendation: 'ACCUMULATE on dips. Strong support near 2400. Digital operations (Jio) boosting retail subscriptions.',
    aiScore: 78,
    rsi: 54,
    macd: 'Bullish Crossover',
    historicalData: generateHistory(2450.50, 30)
  },
  {
    symbol: 'TCS',
    name: 'Tata Consultancy Services Ltd.',
    segment: 'equity',
    price: 3620.00,
    change: -45.50,
    changePercent: -1.24,
    high: 3680.00,
    low: 3605.00,
    open: 3670.00,
    volume: 1800000,
    sector: 'IT Services',
    description: 'A leading global IT services, consulting, and business solutions organization with strong tata pedigree.',
    riskRating: 'Low',
    aiRecommendation: 'HOLD. Premium valuations. Facing temporary spending slow-downs in BFSI sector globally.',
    aiScore: 65,
    rsi: 41,
    macd: 'Bearish Divergence',
    historicalData: generateHistory(3620.00, 30)
  },
  {
    symbol: 'HDFCBANK',
    name: 'HDFC Bank Ltd.',
    segment: 'equity',
    price: 1520.75,
    change: 8.40,
    changePercent: 0.55,
    high: 1532.00,
    low: 1510.50,
    open: 1512.35,
    volume: 9500000,
    sector: 'Banking / Finance',
    description: 'The largest private sector bank in India by assets, offering retail, commercial and corporate financial services.',
    riskRating: 'Low',
    aiRecommendation: 'BUY. Under-valued after merger digestion. Target range 1750. Credit growth remains sturdy.',
    aiScore: 84,
    rsi: 61,
    macd: 'Bullish Flag',
    historicalData: generateHistory(1520.75, 30)
  },
  {
    symbol: 'INFY',
    name: 'Infosys Ltd.',
    segment: 'equity',
    price: 1410.20,
    change: 22.80,
    changePercent: 1.64,
    high: 1421.50,
    low: 1385.00,
    open: 1387.40,
    volume: 3800000,
    sector: 'IT Services',
    description: 'A global leader in next-generation digital services and consulting, serving clients in over 50 countries.',
    riskRating: 'Low',
    aiRecommendation: 'BUY. Digital cloud migration pipelines remain intact. Attractive risk-reward profile here.',
    aiScore: 72,
    rsi: 58,
    macd: 'Bullish Momentum',
    historicalData: generateHistory(1410.20, 30)
  },
  {
    symbol: 'ICICIBANK',
    name: 'ICICI Bank Ltd.',
    segment: 'equity',
    price: 995.60,
    change: -2.30,
    changePercent: -0.23,
    high: 1005.00,
    low: 990.20,
    open: 1002.00,
    volume: 4500000,
    sector: 'Banking / Finance',
    description: 'A leading private sector bank in India offering digital-first retail and high-margin corporate credit products.',
    riskRating: 'Low',
    aiRecommendation: 'BUY. Best-in-class return metrics and solid domestic credit margins. Strong safety cushion.',
    aiScore: 88,
    rsi: 59,
    macd: 'Neutral Consolidation',
    historicalData: generateHistory(995.60, 30)
  },
  {
    symbol: 'NIFTY_FUT',
    name: 'NIFTY 50 Futures',
    segment: 'fando',
    price: 22150.00,
    change: 120.50,
    changePercent: 0.55,
    high: 22210.00,
    low: 22015.00,
    open: 22020.00,
    volume: 850000,
    sector: 'Index Derivative / F&O',
    description: 'Derivative contract tracking the benchmark NIFTY 50 index of top Indian equities. High leverage, highly volatile instrument.',
    riskRating: 'High',
    aiRecommendation: 'SHORT TERM SCALP. Range play 22000-22250. Strict stops below 21950. Keep position sizes small for safe trading.',
    aiScore: 50,
    rsi: 52,
    macd: 'Ranging Pivot',
    historicalData: generateHistory(22150.00, 30)
  },
  {
    symbol: 'RELIANCE_CE_2500',
    name: 'RELIANCE May 2500 Call Option',
    segment: 'fando',
    price: 42.15,
    change: 5.35,
    changePercent: 14.54,
    high: 48.00,
    low: 35.20,
    open: 36.80,
    volume: 3200000,
    sector: 'Stock Derivative / F&O',
    description: 'Leveraged option to purchase Reliance at 2500. Contracts decay rapidly and can completely lose value at expiry.',
    riskRating: 'High',
    aiRecommendation: 'HIGH RISK SPECULATION. Only deploy minor capital. Expected implied volatility spike soon.',
    aiScore: 40,
    rsi: 68,
    macd: 'Extreme Oversold Base',
    historicalData: generateHistory(42.15, 30)
  },
  {
    symbol: 'TATASTEEL',
    name: 'Tata Steel Ltd.',
    segment: 'equity',
    price: 140.50,
    change: 3.10,
    changePercent: 2.26,
    high: 142.00,
    low: 137.20,
    open: 137.40,
    volume: 12000000,
    sector: 'Metals / Mining',
    description: 'One of the world\'s most geographically-diversified steel producers, with steelmaking operations in India and Europe.',
    riskRating: 'Medium',
    aiRecommendation: 'ACCUMULATE. Global infrastructure rebound bolstering metal prices. Margin expansion expected next quarter.',
    aiScore: 71,
    rsi: 63,
    macd: 'Breakout above 20 EMA',
    historicalData: generateHistory(140.50, 30)
  }
];

function generateHistory(basePrice: number, days: number = 30): { time: string; price: number }[] {
  const data = [];
  const start = new Date();
  start.setDate(start.getDate() - days);

  let currentPrice = basePrice * 0.92; // start a bit lower
  for (let i = 0; i < days; i++) {
    const dateStr = start.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
    // dynamic random walk
    const change = (Math.random() - 0.48) * (basePrice * 0.02);
    currentPrice += change;
    data.push({
      time: dateStr,
      price: parseFloat(currentPrice.toFixed(2))
    });
    start.setDate(start.getDate() + 1);
  }

  // Ensure last matches current price exactly
  data[data.length - 1].price = basePrice;
  return data;
}

export function simulateStockTick(stocks: StockData[]): StockData[] {
  return stocks.map(stock => {
    // 0.2% max change per tick
    const percent = (Math.random() - 0.495) * 0.003; 
    const diff = stock.price * percent;
    const newPrice = parseFloat((stock.price + diff).toFixed(2));
    const newChange = parseFloat((stock.change + diff).toFixed(2));
    const newPercent = parseFloat(((newChange / (stock.price - newChange)) * 100).toFixed(2));

    const updatedHistory = [...stock.historicalData];
    if (updatedHistory.length > 0) {
      updatedHistory[updatedHistory.length - 1] = {
        ...updatedHistory[updatedHistory.length - 1],
        price: newPrice
      };
    }

    return {
      ...stock,
      price: newPrice,
      change: newChange,
      changePercent: newPercent,
      high: newPrice > stock.high ? newPrice : stock.high,
      low: newPrice < stock.low ? newPrice : stock.low,
      historicalData: updatedHistory
    };
  });
}
