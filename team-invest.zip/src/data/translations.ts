import { Language } from '../types';

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  en: {
    // Brand & Main Core
    appName: 'Team Invest',
    slogan: 'Safe, Inclusive, Next-Gen Indian Trading Platform',
    riskWarning: 'Attention: Option trading involves high leverage and high risk. 9 out of 10 retail traders lose money in F&O.',
    logout: 'Exit Session',
    guestUser: 'Guest Trader',
    language: 'Language',
    selectLanguage: 'Select Language',
    selectYourPersona: 'Select Persona',
    continueBtn: 'Continue',
    backBtn: 'Back',
    submitBtn: 'Submit',

    // Onboarding Panel & Experience Quiz
    onboardingTitle: 'Secure Financial Onboarding',
    onboardingSub: 'We customize your experience according to your market knowledge to protect you from severe risks.',
    quizProgress: 'Safety Check Progress',
    quizQuestion1: 'What is your prior experience level in securities trading?',
    q1_a1: 'Beginner (Never traded or bought minimal stock)',
    q1_a2: 'Intermediate (1-2 years buying Stocks & Mutual Funds)',
    q1_a3: 'Advanced (Active trader in Derivatives and high-risk products)',
    quizQuestion2: 'What is a Futures and Options (F&O) contract?',
    q2_a1: 'A safe investment that pays regular interest dividends like a bank FD',
    q2_a2: 'A leveraged trading contract to buy/sell assets at set prices — carrying high loss risk',
    q2_a3: 'A free insurance program provided by Indian government for stock traders',
    quizQuestion3: 'According to SEBI regulations, which sector is considered high-risk for retail buyers?',
    q3_a1: 'Simple Equity Delivery long term holding',
    q3_a2: 'Public sector bonds & liquid cash funds',
    q3_a3: 'Intraday F&O derivatives due to leverage',

    // Persona setup description
    assignedPersona: 'Assigned Persona',
    raviTitle: 'Ravi (Beginner Safety Track)',
    raviDesc: 'Equity-only access. Full access to step-by-step risk-free simulation, jargon tooltips, and interactive financial literacy modules. High-risk instruments (F&O) are locked for safety until you complete milestones.',
    snehaTitle: 'Sneha (Active Trader Track)',
    snehaDesc: 'Full access to Equities, F&O, and Commodities. Interactive premium analytics, backtesting engines, risk-adjusted margin alerts, and direct AI-powered trading advice.',
    unlockMessage: 'Securely unlock F&O derivatives after finishing the 3 basic beginner quizzes and making 3 simulator paper trades.',

    // Dashboard navigation
    tabDashboard: 'Terminal',
    tabSimulator: 'Simulator (₹ Practice)',
    tabLearning: 'Learning Academy',
    tabPremium: 'Premium Insights',
    tabFeedback: 'Feedback Box',

    // Stock elements
    symbol: 'Symbol',
    company: 'Company',
    price: 'Price',
    change: 'Change',
    sector: 'Sector',
    action: 'Action',
    buy: 'BUY',
    sell: 'SELL',
    locked: 'Locked for Safety',
    unlocked: 'Unlocked',
    fandoLockedMsg: 'F&O is locked for beginners. Visit the Learning tab to unlock!',
    
    // Order panel
    orderEntry: 'Order entry',
    orderType: 'Order Type',
    quantity: 'Quantity (Lot)',
    limitPrice: 'Limit Price (₹)',
    totalCost: 'Total Cost',
    availBalance: 'Available Balance',
    insufficientFunds: 'Insufficient Balance',
    placeBtn: 'Place Order',
    successMsg: 'Order executed successfully!',
    rejectMsg: 'Order rejected. Check your persona limits or cash balance.',

    // Feedback forms
    feedbackTitle: 'Shape Team Invest MVP',
    feedbackSub: 'Help us build a better alternative to traditional brokers. We value your suggestions.',
    feedbackLanguageOk: 'Are the Hindi/Tamil translations natural and culturally clear?',
    feedbackLanguageLabel: 'Translation Quality',
    feedbackUsageOk: 'Is the platform onboarding risk quiz helpful or annoying?',
    feedbackUsageLabel: 'Safe Onboarding Opinion',
    feedbackFeatureReq: 'What premium tools or features would you like us to prioritize next?',
    feedbackSuccess: 'Thank you! Your feedback has been logged to help refine our premium Indian trading service.',

    // Help Bot UI
    botHealth: 'NLP Assistance Live',
    botPlaceholder: 'Ask in English, Hindi/Tamil about stocks, terminology, or F&O limits...',
    botSafetyGuideline: 'System note: AI will assist you using SEBI-aligned risk explanations in your chosen language.',
    
    // Premium Analytics
    premiumTitle: 'Premium Advanced Insights Dashboard',
    backtestTitle: 'Dynamic Historic Strategy Backtester',
    backtestExpl: 'Simulate a Simple Moving Average (SMA) crossover strategy based on 30-day historical data.',
    smaShort: 'Short SMA Period (Days)',
    smaLong: 'Long SMA Period (Days)',
    runBacktest: 'Execute Backtest Simulation',
    backtestProfit: 'Net Profit Strategy Result',
    totalTrades: 'Total Simulated Signals',
    winRate: 'Win Rate Percentage',
    taxAdvisor: 'Adaptive Capital Gains Tax Estimator (India FY 2026)',
    taxStcg: 'Short Term Capital Gains Taxes (15% on Equity sold under 1 year)',
    taxLtcg: 'Long Term Capital Gains Taxes (10% with 1.25L exemption)',
    advisoryAlerts: 'AI-Generated Advisory Alerts (Indian Stocks)'
  },
  hi: {
    // Brand & Main Core
    appName: 'टीम इन्वेस्ट',
    slogan: 'सुरक्षित, समावेशी, अगली पीढ़ी का भारतीय ट्रेडिंग मंच',
    riskWarning: 'चेतावनी: विकल्प (F&O) ट्रेडिंग में बहुत अधिक निवेश जोखिम होता है। 10 में से 9 निवेशक इसमें पैसे खो देते हैं।',
    logout: 'सत्र समाप्त करें',
    guestUser: 'अतिथि ट्रेडर',
    language: 'भाषा',
    selectLanguage: 'भाषा चुनें',
    selectYourPersona: 'अपनी श्रेणी चुनें',
    continueBtn: 'आगे बढ़ें',
    backBtn: 'पीछे जाएं',
    submitBtn: 'जमा करें',

    // Onboarding Panel & Experience Quiz
    onboardingTitle: 'सुरक्षित वित्तीय ऑनबोर्डिंग',
    onboardingSub: 'हम आपको गंभीर नुकसान से बचाने के लिए आपके बाजार ज्ञान के अनुसार प्लेटफॉर्म की सेवाएं तैयार करते हैं।',
    quizProgress: 'सुरक्षा जांच प्रगति',
    quizQuestion1: 'सिक्योर्ड ट्रेडिंग में आपका पूर्व अनुभव स्तर क्या है?',
    q1_a1: 'शुरुआती (कभी ट्रेडिंग नहीं की या नाममात्र शेयर खरीदे)',
    q1_a2: 'मध्यम (1-2 वर्ष स्टॉक और म्यूचुअल फंड खरीदने का अनुभव)',
    q1_a3: 'उन्नत (डेरिवेटिव और उच्च जोखिम वाले उत्पादों में सक्रिय)',
    quizQuestion2: 'फ्यूचर्स एंड ऑप्शंस (F&O) अनुबंध क्या है?',
    q2_a1: 'एक सुरक्षित निवेश जो बैंक एफडी (FD) की तरह नियमित ब्याज देता है',
    q2_a2: 'तय कीमतों पर स्टॉक खरीदने/बेचने का भारी लीवरेज वाला अनुबंध - जिसमें अत्यधिक जोखिम होता है',
    q2_a3: 'सरकारी वित्त विभाग द्वारा ट्रेडर को दी जाने वाली मुफ्त बीमा योजना',
    quizQuestion3: 'सेबी (SEBI) के नियमों के अनुसार, खुदरा खरीदारों के लिए कौन सा सेक्टर अत्यधिक जोखिम भरा है?',
    q3_a1: 'दीर्घकालिक होल्डिंग के लिए साधारण इक्विटी डिलीवरी',
    q3_a2: 'सरकारी क्षेत्र के बांड और लिक्विड कैश फंड',
    q3_a3: 'लीवरेज के कारण इंट्राडे विकल्प और डेरिवेटिव (F&O)',

    // Persona setup description
    assignedPersona: 'आवंटित श्रेणी',
    raviTitle: 'रवि (शुरुआती सुरक्षा मार्ग)',
    raviDesc: 'केवल साधारण इक्विटी शेयर खरीदने की अनुमति। आपको जोखिम-मुक्त सिमुलेशन, वित्तीय शब्दावली को समझने के लिए टूलटिप्स और ट्यूटोरियल मिलेंगे। सुरक्षा की दृष्टि से उच्च-जोखिम वाले F&O उत्पाद अभी बंद हैं।',
    snehaTitle: 'स्नेहा (सक्रिय ट्रेडर मार्ग)',
    snehaDesc: 'इक्विटी, F&O और कमोडिटी तक पूरी पहुंच। अत्याधुनिक तकनीकी चार्ट, रणनीति का बैकटेस्टिंग इंजन, मार्जिन सूचना और एआई-संचालित स्टॉक सलाह।',
    unlockMessage: 'सभी 3 शुरुआती सुरक्षा अध्याय पूरे करने और 3 सिमुलेटर पेपर ट्रेड करने के बाद सुरक्षापूर्वक F&O अनलॉक करें।',

    // Dashboard navigation
    tabDashboard: 'ट्रेडिंग टर्मिनल',
    tabSimulator: 'सिमुलेटर (₹ अभ्यास)',
    tabLearning: 'लर्निंग एकेडमी',
    tabPremium: 'प्रीमियम विश्लेषण',
    tabFeedback: 'सुझाव पेटी',

    // Stock elements
    symbol: 'प्रतीक',
    company: 'कंपनी',
    price: 'कीमत',
    change: 'बदलाव',
    sector: 'क्षेत्र',
    action: 'ऑर्डर',
    buy: 'खरीदें',
    sell: 'बेचें',
    locked: 'सुरक्षा हेतु बंद',
    unlocked: 'अनलॉक किया गया',
    fandoLockedMsg: 'शुरुआती ट्रेडर के लिए F&O बंद है। इसे खोलने के लिए लर्निंग एकेडमी पर जाएं!',

    // Order panel
    orderEntry: 'ऑर्डर प्रविष्टि',
    orderType: 'ऑर्डर के प्रकार',
    quantity: 'मात्रा (लॉट)',
    limitPrice: 'कीमत सीमा (₹)',
    totalCost: 'कुल लागत',
    availBalance: 'उपलब्ध शेष राशि',
    insufficientFunds: 'अपर्याप्त शेष राशि',
    placeBtn: 'ऑर्डर भेजें',
    successMsg: 'ऑर्डर सफलतापूर्वक निष्पादित हुआ!',
    rejectMsg: 'ऑर्डर खारिज हुआ! अपनी लिमिट या बैलेंस की जांच करें।',

    // Feedback forms
    feedbackTitle: 'टीम इन्वेस्ट सेवा को बेहतर बनाएं',
    feedbackSub: 'पारंपरिक ब्रोकर्स के मुकाबले एक बेहतर विकल्प बनाने में हमारी मदद करें। आपके बहुमूल्य विचार सादर आमंत्रित हैं।',
    feedbackLanguageOk: 'क्या हिंदी और तमिल अनुवाद व्याकरण और समझ की दृष्टि से स्पष्ट हैं?',
    feedbackLanguageLabel: 'अनुवाद की गुणवत्ता',
    feedbackUsageOk: 'क्या सुरक्षित ऑनबोर्डिंग क्विज़ आपको सही लगी या कष्टप्रद?',
    feedbackUsageLabel: 'सुरक्षित ऑनबोर्डिंग पर राय',
    feedbackFeatureReq: 'आप आने वाले समय में किस प्रीमियम टूल को प्राथमिकता देना चाहेंगे?',
    feedbackSuccess: 'धन्यवाद! भारतीय ट्रेडिंग सेवाओं को बेहतर बनाने के लिए आपका सुझाव दर्ज कर लिया गया है।',

    // Help Bot UI
    botHealth: 'एआई भाषा सहायक सक्रिय',
    botPlaceholder: 'हिंदी या अंग्रेजी में स्टॉक, निवेश और सुरक्षा नियमों के बारे में पूछें...',
    botSafetyGuideline: 'प्रणाली नोट: एआई आपको सेबी के सुरक्षा नियमों के तहत स्पष्ट सलाह देगा।',

    // Premium Analytics
    premiumTitle: 'प्रीमियम उन्नत विश्लेषण डैशबोर्ड',
    backtestTitle: 'ऐतिहासिक ट्रेडिंग रणनीति बैकटेस्टर',
    backtestExpl: '30-दिवसीय ऐतिहासिक डेटा के आधार पर सिंपल मूविंग एवरेज (SMA) रणनीतियों का परीक्षण करें।',
    smaShort: 'शॉर्ट एसएमए अवधि (दिन)',
    smaLong: 'लॉन्ग एसएमए अवधि (दिन)',
    runBacktest: 'बैकटेस्ट शुरू करें',
    backtestProfit: 'रणनीति से शुद्ध लाभ प्रतिशत',
    totalTrades: 'सिम्युलेटेड कुल ट्रेड सिग्नल्स',
    winRate: 'विन-रेट अनुपात',
    taxAdvisor: 'भारतीय पूंजीगत लाभ कर गणक (वित्त वर्ष 2026)',
    taxStcg: 'अल्पकालिक पूंजीगत लाभ कर (1 वर्ष से कम इक्विटी बिक्री पर 15%)',
    taxLtcg: 'दीर्घकालिक पूंजीगत लाभ कर (1.25 लाख छूट के साथ 10%)',
    advisoryAlerts: 'प्रीमियम एआई निवेश अलर्ट'
  },
  ta: {
    // Brand & Main Core
    appName: 'டீம் இன்வெஸ்ட்',
    slogan: 'பாதுகாப்பான, உள்ளடக்கிய, அடுத்த தலைமுறை இந்திய வர்த்தக தளம்',
    riskWarning: 'எச்சரிக்கை: ஆப்ஷன்ஸ் வர்த்தகம் அதிக ஆபத்தும் அதிக இழப்பும் கொண்டது. 10 சில்லறை வர்த்தகர்களில் 9 பேர் நஷ்டமடைகிறார்கள்.',
    logout: 'அமர்வு முடிவு',
    guestUser: 'விருந்தினர் வர்த்தகர்',
    language: 'மொழி',
    selectLanguage: 'மொழியைத் தேர்ந்தெடுக்கவும்',
    selectYourPersona: 'உங்கள் பிரிவை தேர்ந்தெடுக்கவும்',
    continueBtn: 'தொடரவும்',
    backBtn: 'பின்னால்',
    submitBtn: 'சமர்ப்பிக்கவும்',

    // Onboarding Panel & Experience Quiz
    onboardingTitle: 'பாதுகாப்பான நிதிச் சேர்க்கை',
    onboardingSub: 'உங்களை பெரும் இழப்புகளில் இருந்து காப்பாற்ற, உங்கள் சந்தை அறிவுக்கு ஏற்ப சேவைகளை எளிதாக்குகிறோம்.',
    quizProgress: 'பாதுகாப்பு சோதனை முன்னேற்றம்',
    quizQuestion1: 'பங்கு வர்த்தகத்தில் உங்கள் முந்தைய அனுபவம் என்ன?',
    q1_a1: 'தொடக்கநிலை (வர்த்தகம் செய்யாதவர் அல்லது குறைந்த பங்குகள் மட்டுமே வாங்கியவர்)',
    q1_a2: 'நடுத்தரமான (1-2 வருடங்கள் பங்குகள் மற்றும் பரஸ்பர நிதிகள் வாங்கியவர்)',
    q1_a3: 'முன்னேறியவர் (மேம்பட்ட ஆப்ஷன்ஸ் மற்றும் அதிக வார்ப்பு கொண்ட தயாரிப்புகளில் வருபவர்)',
    quizQuestion2: 'பியூச்சர்ஸ் மற்றும் ஆப்ஷன்ஸ் (F&O) என்றால் என்ன?',
    q2_a1: 'ஒரு பாதுகாப்பான வைப்பு நிதி, வழக்கமான வட்டி கொடுக்கும் வங்கி வைப்பு போன்றது',
    q2_a2: 'குறிப்பிட்ட விலையில் பங்குகளை வாங்கவோ விற்கவோ லீவரேஜ் ஒப்பந்தம் - அதிக இழப்பு ஆபத்து கொண்டது',
    q2_a3: 'இந்திய அரசால் வர்த்தகர்களுக்கு வழங்கப்படும் இலவச காப்பீட்டுத் திட்டம்',
    quizQuestion3: 'செபி (SEBI) விதிகளின்படி, சில்லறை முதலீட்டாளர்களுக்கு எது அதிக ஆபத்தான முதலீடு ஆகும்?',
    q3_a1: 'நீண்ட கால சாதாரண பங்குகள் வைப்பது',
    q3_a2: 'அரசு பத்திரங்கள் மற்றும் லிக்விட் கேஷ் ஃபண்டுகள்',
    q3_a3: 'அளவுக்கு அதிகமான லீவரேஜ் கொண்ட இன்ட்ராடே ஆப்ஷன்ஸ் வர்த்தகம் (F&O)',

    // Persona setup description
    assignedPersona: 'ஒதுக்கப்பட்ட பிரிவு',
    raviTitle: 'ரவி (தொடக்கநிலை பாதுகாப்பு பாதை)',
    raviDesc: 'சாதாரண பங்குகள் வாங்குவதற்கு மட்டுமே அனுமதி. பாதுகாப்பு இல்லாத ஆபத்துக்களை தவிர்க்க, படிப்படியான காகித வர்த்தகம், எளிய விளக்க குறியீடுகள் மற்றும் கல்வி பாடங்கள் உள்ளன. பாதுகாப்பு காரணங்களால் F&O முடக்கப்பட்டுள்ளது.',
    snehaTitle: 'சினேகா (செயலில் உள்ள வர்த்தகர் பாதை)',
    snehaDesc: 'இக்விட்டி, F&O மற்றும் கமாடிடிக்கு முழு அணுகல். பிரீமியம் பகுப்பாய்வு டூல்கள், உத்திகளைப் பேக்டெஸ்ட் செய்யும் மென்பொருள், ஆபத்து விழிப்புணர்வு தகவல்கள் மற்றும் ஏஐ வர்த்தக அறிவுரைகள்.',
    unlockMessage: '3 எளிமையான பாதுகாப்பு பாடங்கள் மற்றும் 3 மாதிரி காகித வர்த்தகங்களை முடித்த பிறகு பாதுகாப்பாக F&O-ஐ அணுகவும்.',

    // Dashboard navigation
    tabDashboard: 'வர்த்தக முனையம்',
    tabSimulator: 'மாதிரி வர்த்தகம் (₹ பயிற்சி)',
    tabLearning: 'வர்த்தக அகாடமி',
    tabPremium: 'பிரீமியம் நுண்ணறிவு',
    tabFeedback: 'கருத்துப் பெட்டி',

    // Stock elements
    symbol: 'குறியீடு',
    company: 'நிறுவனம்',
    price: 'விலை',
    change: 'மாற்றம்',
    sector: 'துறை',
    action: 'ஆர்டர்',
    buy: 'வாங்கு',
    sell: 'விற்க',
    locked: 'பாதுகாப்புக்கு பூட்டப்பட்டுள்ளது',
    unlocked: 'அன்லாக் செய்யப்பட்டது',
    fandoLockedMsg: 'ஆரம்ப வர்த்தகர்களுக்கு F&O பூட்டப்பட்டுள்ளது. அதைத் திறக்க கல்விப் பகுதிக்குச் செல்லவும்!',

    // Order panel
    orderEntry: 'ஆர்டர் உள்ளீடு',
    orderType: 'ஆர்டர் வகை',
    quantity: 'அளவு (லாட்)',
    limitPrice: 'விலை வரம்பு (₹)',
    totalCost: 'மொத்த மதிப்பு',
    availBalance: 'இருப்பு தொகை',
    insufficientFunds: 'போதிய இருப்பு இல்லை',
    placeBtn: 'ஆர்டர் செய்',
    successMsg: 'ஆர்டர் வெற்றிகரமாக நிறைவேற்றப்பட்டது!',
    rejectMsg: 'ஆர்டர் நிராகரிக்கப்பட்டது! உங்கள் வரம்பு அல்லது இருப்பை சரிபார்க்கவும்.',

    // Feedback forms
    feedbackTitle: 'டீம் இன்வெஸ்ட் தளத்தை மேம்படுத்தவும்',
    feedbackSub: 'மற்ற சாதாரண புரோக்கர்களை விட சிறந்த தளமாக இதை உருவாக்க எங்களுக்கு உதவுங்கள். உங்கள் கருத்துக்கள் வரவேற்கப்படுகின்றன.',
    feedbackLanguageOk: 'தமிழ் மற்றும் இந்தி மொழி மொழிபெயர்ப்புகள் இயல்பாக தெளிவாக உள்ளனவா?',
    feedbackLanguageLabel: 'மொழிபெயர்ப்பு தரம்',
    feedbackUsageOk: 'பாதுகாப்பான ஆன்போர்டிங் வினாடி வினா உங்களுக்கு உதவியாக இருந்ததா அல்லது தொந்தரவாக இருந்ததா?',
    feedbackUsageLabel: 'பாதுகாப்பான ஆன்போர்டிங் கருத்து',
    feedbackFeatureReq: 'எந்த பிரீமியம் அம்சங்களை முதலில் வெளியிட விரும்புகிறீர்கள்?',
    feedbackSuccess: 'நன்றி! இந்திய வர்த்தக சேவையை மேம்படுத்த உங்கள் கருத்துக்கள் பதிவு செய்யப்பட்டுள்ளன.',

    // Help Bot UI
    botHealth: 'மொழியியல் உதவி ஆன்லைனில்',
    botPlaceholder: 'தமிழ் அல்லது ஆங்கிலத்தில் பங்குகள், பாதுகாப்பு விதிகள் பற்றி கேட்கவும்...',
    botSafetyGuideline: 'கணினி குறிப்பு: முதலீட்டு ஆபத்துகள் குறித்து செபி விதிகளை பின்பற்றி ஏஐ உங்களுக்கு வழிகாட்டும்.',

    // Premium Analytics
    premiumTitle: 'பிரீமியம் மேம்பட்ட பகுப்பாய்வு போர்டல்',
    backtestTitle: 'வரலாற்று உத்திகளை சோதிக்கும் போர்டு',
    backtestExpl: '30 நாள் வரலாற்றுத் தரவுகளின் அடிப்படையில் சிம்பிள் மூவிங் ஆவரேஜ் (SMA) உத்திகளை பகுப்பாய்வு செய்யுங்கள்.',
    smaShort: 'குறுகிய SMA காலம் (நாட்கள்)',
    smaLong: 'நீண்ட SMA காலம் (நாட்கள்)',
    runBacktest: 'உத்தியை சோதி',
    backtestProfit: 'உத்தியின் நிகர லாபம் சதவீதம்',
    totalTrades: 'சோதிக்கப்பட்ட வர்த்தக சமிக்ஞைகள்',
    winRate: 'வெற்றி விகிதம் சதவீதம்',
    taxAdvisor: 'இந்திய மூலதன ஆதாய வரி கணக்கிப்பான் (நிதியாண்டு 2026)',
    taxStcg: 'குறுகிய கால மூலதன ஆதாய வரி (1 ஆண்டிற்குள் விற்றால் 15%)',
    taxLtcg: 'நீண்ட கால மூலதன ஆதாய வரி (1.25 லட்சம் விலக்கு போக 10%)',
    advisoryAlerts: 'ஏஐ-உருவாக்கிய பிரீமியம் முதலீட்டு அலர்ட்கள்'
  }
};
